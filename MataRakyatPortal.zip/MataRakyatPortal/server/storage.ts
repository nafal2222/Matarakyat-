import {
  users,
  missions,
  missionBids,
  payments,
  evidence,
  missionUpdates,
  notifications,
  reviews,
  type User,
  type UpsertUser,
  type Mission,
  type InsertMission,
  type MissionBid,
  type InsertMissionBid,
  type Payment,
  type InsertPayment,
  type Evidence,
  type InsertEvidence,
  type MissionUpdate,
  type InsertMissionUpdate,
  type Notification,
  type InsertNotification,
  type Review,
  type InsertReview,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, sql, gte, lte, ilike, or, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  getUsers(filters?: { email?: string; role?: string }): Promise<User[]>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStats(userId: string, stats: Partial<Pick<User, 'rating' | 'completedMissions' | 'successRate' | 'totalEarnings'>>): Promise<void>;

  // Mission operations
  createMission(mission: InsertMission): Promise<Mission>;
  getMission(id: string): Promise<Mission | undefined>;
  getMissions(filters?: {
    status?: string[];
    category?: string[];
    priority?: string[];
    providerId?: string;
    assignedTo?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ missions: Mission[]; total: number }>;
  updateMissionStatus(id: string, status: string, assignedTo?: string): Promise<void>;
  assignMission(id: string, executorId: string): Promise<void>;
  completeMission(id: string): Promise<void>;
  verifyMission(id: string): Promise<void>;

  // Mission bid operations
  createBid(bid: InsertMissionBid): Promise<MissionBid>;
  getMissionBids(missionId: string): Promise<MissionBid[]>;
  getUserBids(userId: string): Promise<MissionBid[]>;
  updateBidStatus(id: string, status: string): Promise<void>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  escrowPayment(paymentId: string): Promise<void>;
  releasePayment(paymentId: string): Promise<void>;
  refundPayment(paymentId: string): Promise<void>;
  getMissionPayments(missionId: string): Promise<Payment[]>;
  getUserPayments(userId: string): Promise<Payment[]>;

  // Evidence operations
  createEvidence(evidence: InsertEvidence): Promise<Evidence>;
  getMissionEvidence(missionId: string): Promise<Evidence[]>;
  verifyEvidence(id: string, verifiedBy: string): Promise<void>;

  // Mission update operations
  createMissionUpdate(update: InsertMissionUpdate): Promise<MissionUpdate>;
  getMissionUpdates(missionId: string): Promise<MissionUpdate[]>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, unreadOnly?: boolean): Promise<Notification[]>;
  markNotificationRead(id: string): Promise<void>;
  markAllNotificationsRead(userId: string): Promise<void>;

  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getMissionReviews(missionId: string): Promise<Review[]>;
  getUserReviews(userId: string): Promise<Review[]>;

  // Analytics
  getDashboardStats(userId: string, role: string): Promise<{
    activeMissions: number;
    completedToday: number;
    pendingReview: number;
    totalEarnings: string;
    recentActivities: any[];
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUsers(filters?: { email?: string; role?: string }): Promise<User[]> {
    let query = db.select().from(users);
    
    if (filters?.email) {
      query = query.where(eq(users.email, filters.email));
    }
    
    if (filters?.role) {
      query = query.where(eq(users.role, filters.role));
    }
    
    return await query;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStats(userId: string, stats: Partial<Pick<User, 'rating' | 'completedMissions' | 'successRate' | 'totalEarnings'>>): Promise<void> {
    await db
      .update(users)
      .set({ ...stats, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  // Mission operations
  async createMission(mission: InsertMission): Promise<Mission> {
    const [newMission] = await db.insert(missions).values(mission).returning();
    return newMission;
  }

  async getMission(id: string): Promise<Mission | undefined> {
    const [mission] = await db.select().from(missions).where(eq(missions.id, id));
    return mission;
  }

  async getMissions(filters: {
    status?: string[];
    category?: string[];
    priority?: string[];
    providerId?: string;
    assignedTo?: string;
    search?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<{ missions: Mission[]; total: number }> {
    let query = db.select().from(missions);
    let countQuery = db.select({ count: count() }).from(missions);

    const conditions = [];

    if (filters.status?.length) {
      conditions.push(inArray(missions.status, filters.status as any));
    }
    if (filters.category?.length) {
      conditions.push(inArray(missions.category, filters.category as any));
    }
    if (filters.priority?.length) {
      conditions.push(inArray(missions.priority, filters.priority as any));
    }
    if (filters.providerId) {
      conditions.push(eq(missions.providerId, filters.providerId));
    }
    if (filters.assignedTo) {
      conditions.push(eq(missions.assignedTo, filters.assignedTo));
    }
    if (filters.search) {
      conditions.push(
        or(
          ilike(missions.title, `%${filters.search}%`),
          ilike(missions.description, `%${filters.search}%`),
          ilike(missions.location, `%${filters.search}%`)
        )
      );
    }

    if (conditions.length > 0) {
      const whereClause = and(...conditions);
      query = query.where(whereClause);
      countQuery = countQuery.where(whereClause);
    }

    query = query.orderBy(desc(missions.createdAt));

    if (filters.limit) {
      query = query.limit(filters.limit);
    }
    if (filters.offset) {
      query = query.offset(filters.offset);
    }

    const [missionResults, countResults] = await Promise.all([
      query,
      countQuery
    ]);

    return {
      missions: missionResults,
      total: countResults[0].count
    };
  }

  async updateMissionStatus(id: string, status: string, assignedTo?: string): Promise<void> {
    const updateData: any = { status, updatedAt: new Date() };
    if (assignedTo) {
      updateData.assignedTo = assignedTo;
    }
    if (status === 'completed') {
      updateData.completedAt = new Date();
    }
    if (status === 'verified') {
      updateData.verifiedAt = new Date();
    }

    await db.update(missions).set(updateData).where(eq(missions.id, id));
  }

  async assignMission(id: string, executorId: string): Promise<void> {
    await db
      .update(missions)
      .set({
        assignedTo: executorId,
        status: 'assigned',
        updatedAt: new Date(),
      })
      .where(eq(missions.id, id));
  }

  async completeMission(id: string): Promise<void> {
    await db
      .update(missions)
      .set({
        status: 'completed',
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(missions.id, id));
  }

  async verifyMission(id: string): Promise<void> {
    await db
      .update(missions)
      .set({
        status: 'verified',
        verifiedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(missions.id, id));
  }

  // Mission bid operations
  async createBid(bid: InsertMissionBid): Promise<MissionBid> {
    const [newBid] = await db.insert(missionBids).values(bid).returning();
    return newBid;
  }

  async getMissionBids(missionId: string): Promise<MissionBid[]> {
    return await db
      .select()
      .from(missionBids)
      .where(eq(missionBids.missionId, missionId))
      .orderBy(asc(missionBids.bidAmount));
  }

  async getUserBids(userId: string): Promise<MissionBid[]> {
    return await db
      .select()
      .from(missionBids)
      .where(eq(missionBids.executorId, userId))
      .orderBy(desc(missionBids.createdAt));
  }

  async updateBidStatus(id: string, status: string): Promise<void> {
    await db
      .update(missionBids)
      .set({ status: status as any })
      .where(eq(missionBids.id, id));
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async escrowPayment(paymentId: string): Promise<void> {
    await db
      .update(payments)
      .set({
        status: 'escrowed',
        escrowedAt: new Date(),
      })
      .where(eq(payments.id, paymentId));
  }

  async releasePayment(paymentId: string): Promise<void> {
    await db
      .update(payments)
      .set({
        status: 'released',
        releasedAt: new Date(),
      })
      .where(eq(payments.id, paymentId));
  }

  async refundPayment(paymentId: string): Promise<void> {
    await db
      .update(payments)
      .set({
        status: 'refunded',
        refundedAt: new Date(),
      })
      .where(eq(payments.id, paymentId));
  }

  async getMissionPayments(missionId: string): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.missionId, missionId));
  }

  async getUserPayments(userId: string): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(or(eq(payments.providerId, userId), eq(payments.executorId, userId)))
      .orderBy(desc(payments.createdAt));
  }

  // Evidence operations
  async createEvidence(evidence: InsertEvidence): Promise<Evidence> {
    const [newEvidence] = await db.insert(evidence).values(evidence).returning();
    return newEvidence;
  }

  async getMissionEvidence(missionId: string): Promise<Evidence[]> {
    return await db
      .select()
      .from(evidence)
      .where(eq(evidence.missionId, missionId))
      .orderBy(desc(evidence.createdAt));
  }

  async verifyEvidence(id: string, verifiedBy: string): Promise<void> {
    await db
      .update(evidence)
      .set({
        isVerified: true,
        verifiedBy,
        verifiedAt: new Date(),
      })
      .where(eq(evidence.id, id));
  }

  // Mission update operations
  async createMissionUpdate(update: InsertMissionUpdate): Promise<MissionUpdate> {
    const [newUpdate] = await db.insert(missionUpdates).values(update).returning();
    return newUpdate;
  }

  async getMissionUpdates(missionId: string): Promise<MissionUpdate[]> {
    return await db
      .select()
      .from(missionUpdates)
      .where(eq(missionUpdates.missionId, missionId))
      .orderBy(desc(missionUpdates.createdAt));
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async getUserNotifications(userId: string, unreadOnly: boolean = false): Promise<Notification[]> {
    let query = db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId));

    if (unreadOnly) {
      query = query.where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    }

    return await query.orderBy(desc(notifications.createdAt));
  }

  async markNotificationRead(id: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }

  async markAllNotificationsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }

  // Review operations
  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }

  async getMissionReviews(missionId: string): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.missionId, missionId))
      .orderBy(desc(reviews.createdAt));
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.revieweeId, userId))
      .orderBy(desc(reviews.createdAt));
  }

  // Analytics
  async getDashboardStats(userId: string, role: string): Promise<{
    activeMissions: number;
    completedToday: number;
    pendingReview: number;
    totalEarnings: string;
    recentActivities: any[];
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    let activeMissionsQuery, completedTodayQuery, pendingReviewQuery, earningsQuery;

    if (role === 'mission_provider') {
      activeMissionsQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.providerId, userId),
          inArray(missions.status, ['pending', 'assigned', 'in_progress'])
        ));

      completedTodayQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.providerId, userId),
          eq(missions.status, 'completed'),
          gte(missions.completedAt, today),
          lte(missions.completedAt, tomorrow)
        ));

      pendingReviewQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.providerId, userId),
          eq(missions.status, 'completed')
        ));

      earningsQuery = db
        .select({ total: sql<string>`COALESCE(SUM(${payments.amount} - ${payments.commission}), 0)` })
        .from(payments)
        .where(and(
          eq(payments.providerId, userId),
          eq(payments.status, 'released')
        ));
    } else {
      activeMissionsQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.assignedTo, userId),
          inArray(missions.status, ['assigned', 'in_progress'])
        ));

      completedTodayQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.assignedTo, userId),
          eq(missions.status, 'completed'),
          gte(missions.completedAt, today),
          lte(missions.completedAt, tomorrow)
        ));

      pendingReviewQuery = db
        .select({ count: count() })
        .from(missions)
        .where(and(
          eq(missions.assignedTo, userId),
          eq(missions.status, 'completed')
        ));

      earningsQuery = db
        .select({ total: sql<string>`COALESCE(SUM(${payments.amount} - ${payments.commission}), 0)` })
        .from(payments)
        .where(and(
          eq(payments.executorId, userId),
          eq(payments.status, 'released')
        ));
    }

    const recentActivitiesQuery = db
      .select()
      .from(missionUpdates)
      .where(eq(missionUpdates.userId, userId))
      .orderBy(desc(missionUpdates.createdAt))
      .limit(10);

    const [
      activeMissionsResult,
      completedTodayResult,
      pendingReviewResult,
      earningsResult,
      recentActivitiesResult
    ] = await Promise.all([
      activeMissionsQuery,
      completedTodayQuery,
      pendingReviewQuery,
      earningsQuery,
      recentActivitiesQuery
    ]);

    return {
      activeMissions: activeMissionsResult[0].count,
      completedToday: completedTodayResult[0].count,
      pendingReview: pendingReviewResult[0].count,
      totalEarnings: earningsResult[0].total || '0',
      recentActivities: recentActivitiesResult
    };
  }
}

export const storage = new DatabaseStorage();

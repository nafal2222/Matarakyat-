import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { setupDemoAuth, requireDemoAuth, requireAdminRole } from "./demoAuth";
import { insertMissionSchema, insertMissionBidSchema, insertEvidenceSchema, insertMissionUpdateSchema, insertReviewSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Check if we should use demo auth (for VPS hosting)
  if (process.env.DEMO_MODE === 'true' || !process.env.REPLIT_DOMAINS) {
    console.log('🎯 Demo mode aktif - menggunakan login password sederhana');
    setupDemoAuth(app);
  } else {
    console.log('🔐 Production mode - menggunakan Replit Auth');
    await setupAuth(app);
  }

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const stats = await storage.getDashboardStats(userId, user.role);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Mission routes
  app.post('/api/missions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const missionData = insertMissionSchema.parse({
        ...req.body,
        providerId: userId
      });
      
      const mission = await storage.createMission(missionData);
      
      // Create notification for new mission
      await storage.createNotification({
        userId,
        type: 'mission_update',
        title: 'Mission Created',
        content: `Your mission "${mission.title}" has been created successfully.`,
        relatedId: mission.id
      });

      res.json(mission);
    } catch (error) {
      console.error("Error creating mission:", error);
      res.status(500).json({ message: "Failed to create mission" });
    }
  });

  app.get('/api/missions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const filters: any = {
        limit: parseInt(req.query.limit as string) || 20,
        offset: parseInt(req.query.offset as string) || 0,
      };

      if (req.query.status) {
        filters.status = Array.isArray(req.query.status) ? req.query.status : [req.query.status];
      }
      if (req.query.category) {
        filters.category = Array.isArray(req.query.category) ? req.query.category : [req.query.category];
      }
      if (req.query.priority) {
        filters.priority = Array.isArray(req.query.priority) ? req.query.priority : [req.query.priority];
      }
      if (req.query.search) {
        filters.search = req.query.search as string;
      }

      // Role-based filtering
      if (user?.role === 'mission_provider') {
        filters.providerId = userId;
      } else if (user?.role === 'mission_executor' || user?.role === 'agent') {
        if (req.query.my_missions === 'true') {
          filters.assignedTo = userId;
        }
      }

      const result = await storage.getMissions(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching missions:", error);
      res.status(500).json({ message: "Failed to fetch missions" });
    }
  });

  app.get('/api/missions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const mission = await storage.getMission(req.params.id);
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }
      res.json(mission);
    } catch (error) {
      console.error("Error fetching mission:", error);
      res.status(500).json({ message: "Failed to fetch mission" });
    }
  });

  app.patch('/api/missions/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { status, assignedTo } = req.body;
      await storage.updateMissionStatus(req.params.id, status, assignedTo);
      
      const mission = await storage.getMission(req.params.id);
      if (mission) {
        // Create notification for status update
        const targetUserId = assignedTo || mission.providerId;
        await storage.createNotification({
          userId: targetUserId,
          type: 'mission_update',
          title: 'Mission Status Updated',
          content: `Mission "${mission.title}" status changed to ${status}.`,
          relatedId: mission.id
        });
      }

      res.json({ message: "Mission status updated successfully" });
    } catch (error) {
      console.error("Error updating mission status:", error);
      res.status(500).json({ message: "Failed to update mission status" });
    }
  });

  app.post('/api/missions/:id/assign', isAuthenticated, async (req: any, res) => {
    try {
      const { executorId } = req.body;
      await storage.assignMission(req.params.id, executorId);
      
      const mission = await storage.getMission(req.params.id);
      if (mission) {
        // Create notifications
        await Promise.all([
          storage.createNotification({
            userId: executorId,
            type: 'assignment',
            title: 'Mission Assigned',
            content: `You have been assigned to mission "${mission.title}".`,
            relatedId: mission.id
          }),
          storage.createNotification({
            userId: mission.providerId,
            type: 'assignment',
            title: 'Mission Assigned',
            content: `Your mission "${mission.title}" has been assigned to an executor.`,
            relatedId: mission.id
          })
        ]);
      }

      res.json({ message: "Mission assigned successfully" });
    } catch (error) {
      console.error("Error assigning mission:", error);
      res.status(500).json({ message: "Failed to assign mission" });
    }
  });

  // Mission bid routes
  app.post('/api/missions/:id/bids', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bidData = insertMissionBidSchema.parse({
        ...req.body,
        missionId: req.params.id,
        executorId: userId
      });
      
      const bid = await storage.createBid(bidData);
      
      const mission = await storage.getMission(req.params.id);
      if (mission) {
        // Notify mission provider
        await storage.createNotification({
          userId: mission.providerId,
          type: 'mission_update',
          title: 'New Bid Received',
          content: `You received a new bid for mission "${mission.title}".`,
          relatedId: mission.id
        });
      }

      res.json(bid);
    } catch (error) {
      console.error("Error creating bid:", error);
      res.status(500).json({ message: "Failed to create bid" });
    }
  });

  app.get('/api/missions/:id/bids', isAuthenticated, async (req: any, res) => {
    try {
      const bids = await storage.getMissionBids(req.params.id);
      res.json(bids);
    } catch (error) {
      console.error("Error fetching bids:", error);
      res.status(500).json({ message: "Failed to fetch bids" });
    }
  });

  app.patch('/api/bids/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { status } = req.body;
      await storage.updateBidStatus(req.params.id, status);
      res.json({ message: "Bid status updated successfully" });
    } catch (error) {
      console.error("Error updating bid status:", error);
      res.status(500).json({ message: "Failed to update bid status" });
    }
  });

  // Evidence routes
  app.post('/api/missions/:id/evidence', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const evidenceData = insertEvidenceSchema.parse({
        ...req.body,
        missionId: req.params.id,
        uploadedBy: userId
      });
      
      const evidence = await storage.createEvidence(evidenceData);
      
      const mission = await storage.getMission(req.params.id);
      if (mission) {
        // Notify relevant parties
        const notifyUsers = [mission.providerId];
        if (mission.assignedTo && mission.assignedTo !== userId) {
          notifyUsers.push(mission.assignedTo);
        }

        await Promise.all(notifyUsers.map(notifyUserId => 
          storage.createNotification({
            userId: notifyUserId,
            type: 'mission_update',
            title: 'New Evidence Uploaded',
            content: `New evidence has been uploaded for mission "${mission.title}".`,
            relatedId: mission.id
          })
        ));
      }

      res.json(evidence);
    } catch (error) {
      console.error("Error uploading evidence:", error);
      res.status(500).json({ message: "Failed to upload evidence" });
    }
  });

  app.get('/api/missions/:id/evidence', isAuthenticated, async (req: any, res) => {
    try {
      const evidence = await storage.getMissionEvidence(req.params.id);
      res.json(evidence);
    } catch (error) {
      console.error("Error fetching evidence:", error);
      res.status(500).json({ message: "Failed to fetch evidence" });
    }
  });

  app.patch('/api/evidence/:id/verify', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.verifyEvidence(req.params.id, userId);
      res.json({ message: "Evidence verified successfully" });
    } catch (error) {
      console.error("Error verifying evidence:", error);
      res.status(500).json({ message: "Failed to verify evidence" });
    }
  });

  // Mission update routes
  app.post('/api/missions/:id/updates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updateData = insertMissionUpdateSchema.parse({
        ...req.body,
        missionId: req.params.id,
        userId
      });
      
      const update = await storage.createMissionUpdate(updateData);
      res.json(update);
    } catch (error) {
      console.error("Error creating mission update:", error);
      res.status(500).json({ message: "Failed to create mission update" });
    }
  });

  app.get('/api/missions/:id/updates', isAuthenticated, async (req: any, res) => {
    try {
      const updates = await storage.getMissionUpdates(req.params.id);
      res.json(updates);
    } catch (error) {
      console.error("Error fetching mission updates:", error);
      res.status(500).json({ message: "Failed to fetch mission updates" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const unreadOnly = req.query.unread_only === 'true';
      const notifications = await storage.getUserNotifications(userId, unreadOnly);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      await storage.markNotificationRead(req.params.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch('/api/notifications/read-all', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.markAllNotificationsRead(userId);
      res.json({ message: "All notifications marked as read" });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Review routes
  app.post('/api/missions/:id/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        missionId: req.params.id,
        reviewerId: userId
      });
      
      const review = await storage.createReview(reviewData);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get('/api/missions/:id/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const reviews = await storage.getMissionReviews(req.params.id);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get('/api/users/:id/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const reviews = await storage.getUserReviews(req.params.id);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching user reviews:", error);
      res.status(500).json({ message: "Failed to fetch user reviews" });
    }
  });

  // Payment routes
  app.post('/api/payments', isAuthenticated, async (req: any, res) => {
    try {
      const payment = await storage.createPayment(req.body);
      res.json(payment);
    } catch (error) {
      console.error("Error creating payment:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.patch('/api/payments/:id/escrow', isAuthenticated, async (req: any, res) => {
    try {
      await storage.escrowPayment(req.params.id);
      res.json({ message: "Payment escrowed successfully" });
    } catch (error) {
      console.error("Error escrowing payment:", error);
      res.status(500).json({ message: "Failed to escrow payment" });
    }
  });

  app.patch('/api/payments/:id/release', isAuthenticated, async (req: any, res) => {
    try {
      await storage.releasePayment(req.params.id);
      res.json({ message: "Payment released successfully" });
    } catch (error) {
      console.error("Error releasing payment:", error);
      res.status(500).json({ message: "Failed to release payment" });
    }
  });

  app.get('/api/users/:id/payments', isAuthenticated, async (req: any, res) => {
    try {
      const payments = await storage.getUserPayments(req.params.id);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching user payments:", error);
      res.status(500).json({ message: "Failed to fetch user payments" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import connectPg from "connect-pg-simple";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

// Hash password menggunakan scrypt
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Bandingkan password
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Demo users dengan password default
const DEMO_CREDENTIALS = {
  'admin@matarakyat.demo': 'admin123',
  'agent@matarakyat.demo': 'agent123', 
  'provider@matarakyat.demo': 'provider123',
  'executor@matarakyat.demo': 'executor123'
};

export function setupDemoAuth(app: Express) {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "sessions",
  });

  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'demo-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: sessionTtl,
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Local Strategy untuk demo login
  passport.use(
    new LocalStrategy(
      { usernameField: 'email', passwordField: 'password' },
      async (email, password, done) => {
        try {
          // Cek apakah ini demo credentials
          const demoPassword = DEMO_CREDENTIALS[email as keyof typeof DEMO_CREDENTIALS];
          if (demoPassword && demoPassword === password) {
            // Ambil user dari database berdasarkan email
            const users = await storage.getUsers({ email });
            const user = users.find(u => u.email === email);
            
            if (user) {
              return done(null, user);
            } else {
              return done(null, false, { message: 'User demo tidak ditemukan di database' });
            }
          }
          
          return done(null, false, { message: 'Email atau password salah' });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user, done) => done(null, user.id));
  
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user || null);
    } catch (error) {
      done(error);
    }
  });

  // Login endpoint
  app.post("/api/demo/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json({
      success: true,
      user: req.user,
      message: 'Login berhasil'
    });
  });

  // Logout endpoint
  app.post("/api/demo/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.status(200).json({ 
        success: true, 
        message: 'Logout berhasil' 
      });
    });
  });

  // Get current user
  app.get("/api/demo/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ 
        success: false, 
        message: 'Tidak terautentikasi' 
      });
    }
    res.json({
      success: true,
      user: req.user
    });
  });

  // Demo info endpoint
  app.get("/api/demo/info", (req, res) => {
    res.json({
      success: true,
      message: 'Demo mode aktif',
      accounts: Object.keys(DEMO_CREDENTIALS).map(email => ({
        email,
        password: DEMO_CREDENTIALS[email as keyof typeof DEMO_CREDENTIALS],
        role: email.includes('admin') ? 'admin' : 
              email.includes('agent') ? 'agent' :
              email.includes('provider') ? 'mission_provider' : 'mission_executor'
      }))
    });
  });
}

// Middleware untuk proteksi route
export const requireDemoAuth = (req: any, res: any, next: any) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ 
      success: false, 
      message: 'Akses ditolak - login diperlukan' 
    });
  }
  next();
};

// Middleware untuk admin only
export const requireAdminRole = (req: any, res: any, next: any) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ 
      success: false, 
      message: 'Akses ditolak - login diperlukan' 
    });
  }
  
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ 
      success: false, 
      message: 'Akses ditolak - hanya admin yang diizinkan' 
    });
  }
  
  next();
};
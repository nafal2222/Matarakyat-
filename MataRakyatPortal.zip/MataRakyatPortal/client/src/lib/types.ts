export interface DashboardStats {
  activeMissions: number;
  completedToday: number;
  pendingReview: number;
  totalEarnings: string;
  recentActivities: RecentActivity[];
}

export interface RecentActivity {
  id: string;
  type: 'mission_update' | 'assignment' | 'payment' | 'evidence';
  title: string;
  description: string;
  timestamp: string;
  relatedId?: string;
}

export interface MissionFilters {
  status?: string[];
  category?: string[];
  priority?: string[];
  search?: string;
  myMissions?: boolean;
  limit?: number;
  offset?: number;
}

export interface MissionWithDetails {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  location: string;
  budget: string;
  deadline: string;
  providerId: string;
  assignedTo?: string;
  requirements?: string;
  skills?: string[];
  isUrgent: boolean;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  verifiedAt?: string;
}

export const MISSION_STATUSES = [
  { value: 'pending', label: 'Pending', color: 'yellow' },
  { value: 'assigned', label: 'Assigned', color: 'blue' },
  { value: 'in_progress', label: 'In Progress', color: 'orange' },
  { value: 'completed', label: 'Completed', color: 'green' },
  { value: 'verified', label: 'Verified', color: 'emerald' },
  { value: 'cancelled', label: 'Cancelled', color: 'red' },
  { value: 'disputed', label: 'Disputed', color: 'purple' },
];

export const MISSION_CATEGORIES = [
  { value: 'missing_person', label: 'Missing Person' },
  { value: 'lost_items', label: 'Lost Items' },
  { value: 'surveillance', label: 'Surveillance' },
  { value: 'investigation', label: 'Investigation' },
  { value: 'background_check', label: 'Background Check' },
  { value: 'security', label: 'Security' },
];

export const MISSION_PRIORITIES = [
  { value: 'low', label: 'Low', color: 'gray' },
  { value: 'standard', label: 'Standard', color: 'blue' },
  { value: 'high', label: 'High', color: 'orange' },
  { value: 'urgent', label: 'Urgent', color: 'red' },
];

export const USER_ROLES = [
  { value: 'admin', label: 'Administrator' },
  { value: 'agent', label: 'Agent' },
  { value: 'mission_provider', label: 'Mission Provider' },
  { value: 'mission_executor', label: 'Mission Executor' },
];

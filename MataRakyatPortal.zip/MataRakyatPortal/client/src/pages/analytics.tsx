import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/layout/navigation";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Users, DollarSign, Clock, CheckCircle, AlertTriangle, Award } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Analytics() {
  const { user } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  if (!user) return null;

  const mockAnalytics = {
    performance: {
      successRate: 94,
      averageCompletionTime: 3.2,
      customerSatisfaction: 4.7,
      totalMissions: 47
    },
    earnings: {
      thisMonth: 4250,
      lastMonth: 3890,
      growth: 9.3,
      pending: 850
    },
    missions: {
      completed: 42,
      inProgress: 5,
      pending: 8,
      cancelled: 2
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 lg:ml-64 p-6">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Analytics & Reports</h1>
            <p className="text-muted-foreground mt-1">
              Comprehensive insights into your performance and earnings
            </p>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="earnings">Earnings</TabsTrigger>
              <TabsTrigger value="missions">Missions</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-500">{mockAnalytics.performance.successRate}%</div>
                    <Progress value={mockAnalytics.performance.successRate} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-2">
                      +2.5% from last month
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Monthly Earnings</CardTitle>
                    <DollarSign className="h-4 w-4 text-primary" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${mockAnalytics.earnings.thisMonth.toLocaleString()}</div>
                    <div className="flex items-center text-xs text-green-500 mt-2">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +{mockAnalytics.earnings.growth}% from last month
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Avg. Completion</CardTitle>
                    <Clock className="h-4 w-4 text-blue-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockAnalytics.performance.averageCompletionTime} days</div>
                    <p className="text-xs text-muted-foreground mt-2">
                      0.3 days faster than average
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Missions</CardTitle>
                    <Users className="h-4 w-4 text-purple-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockAnalytics.performance.totalMissions}</div>
                    <p className="text-xs text-muted-foreground mt-2">
                      5 completed this month
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Charts and Recent Activity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Mission Status Distribution</CardTitle>
                    <CardDescription>Current status of all your missions</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm">Completed</span>
                      </div>
                      <span className="font-semibold">{mockAnalytics.missions.completed}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">In Progress</span>
                      </div>
                      <span className="font-semibold">{mockAnalytics.missions.inProgress}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm">Pending</span>
                      </div>
                      <span className="font-semibold">{mockAnalytics.missions.pending}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-sm">Cancelled</span>
                      </div>
                      <span className="font-semibold">{mockAnalytics.missions.cancelled}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Achievements</CardTitle>
                    <CardDescription>Your latest milestones and accomplishments</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-gold/20 p-2 rounded-lg">
                        <Award className="h-4 w-4 text-yellow-500" />
                      </div>
                      <div>
                        <p className="font-medium">Top Performer</p>
                        <p className="text-sm text-muted-foreground">Achieved 95%+ success rate</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="bg-green-500/20 p-2 rounded-lg">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </div>
                      <div>
                        <p className="font-medium">Fast Completion</p>
                        <p className="text-sm text-muted-foreground">Completed 5 missions under deadline</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="bg-blue-500/20 p-2 rounded-lg">
                        <TrendingUp className="h-4 w-4 text-blue-500" />
                      </div>
                      <div>
                        <p className="font-medium">Earnings Growth</p>
                        <p className="text-sm text-muted-foreground">10% increase from last month</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      Success Rate
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-500 mb-2">
                      {mockAnalytics.performance.successRate}%
                    </div>
                    <Progress value={mockAnalytics.performance.successRate} className="mb-2" />
                    <p className="text-sm text-muted-foreground">
                      Industry average: 78%
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-blue-500" />
                      Avg. Completion Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-500 mb-2">
                      {mockAnalytics.performance.averageCompletionTime} days
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Target: &lt; 5 days
                    </p>
                    <Badge className="mt-2 bg-green-500/20 text-green-400">
                      Above Target
                    </Badge>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Award className="h-5 w-5 mr-2 text-yellow-500" />
                      Customer Rating
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-yellow-500 mb-2">
                      {mockAnalytics.performance.customerSatisfaction}/5.0
                    </div>
                    <div className="flex space-x-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <div 
                          key={i} 
                          className={`w-4 h-4 rounded-full ${
                            i < Math.floor(mockAnalytics.performance.customerSatisfaction) 
                              ? 'bg-yellow-500' 
                              : 'bg-gray-600'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Based on 47 reviews
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="earnings" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>This Month</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-primary">
                      ${mockAnalytics.earnings.thisMonth.toLocaleString()}
                    </div>
                    <div className="flex items-center text-sm text-green-500 mt-1">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      +{mockAnalytics.earnings.growth}%
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Last Month</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      ${mockAnalytics.earnings.lastMonth.toLocaleString()}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Previous period
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Pending</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-yellow-500">
                      ${mockAnalytics.earnings.pending.toLocaleString()}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Awaiting payment
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Total Earned</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-500">
                      ${(mockAnalytics.earnings.thisMonth + mockAnalytics.earnings.lastMonth + 8560).toLocaleString()}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      All time earnings
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="missions" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Mission Categories</CardTitle>
                    <CardDescription>Your specializations and focus areas</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Missing Person</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={65} className="w-20" />
                        <span className="text-sm font-medium">18</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Surveillance</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={45} className="w-20" />
                        <span className="text-sm font-medium">12</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Lost Items</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={35} className="w-20" />
                        <span className="text-sm font-medium">9</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Investigation</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={25} className="w-20" />
                        <span className="text-sm font-medium">6</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Trend</CardTitle>
                    <CardDescription>Mission completion over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">January</span>
                        <span className="font-medium">8 missions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">February</span>
                        <span className="font-medium">12 missions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">March</span>
                        <span className="font-medium">15 missions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-primary">March (Current)</span>
                        <span className="font-medium text-primary">5 missions</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

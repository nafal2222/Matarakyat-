import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/layout/navigation";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Search, Filter, Eye, Download, Shield, Clock, CheckCircle, FileText, Image, Video, Mic } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Evidence() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMission, setSelectedMission] = useState<string>("all");
  const [evidenceType, setEvidenceType] = useState<string>("all");

  const { data: missions } = useQuery({
    queryKey: ['/api/missions', { my_missions: true }],
  });

  const { data: evidence, isLoading } = useQuery({
    queryKey: ['/api/evidence', { search: searchQuery, mission: selectedMission, type: evidenceType }],
  });

  const getEvidenceIcon = (type: string) => {
    switch (type) {
      case 'image': return <Image className="h-4 w-4" />;
      case 'video': return <Video className="h-4 w-4" />;
      case 'audio': return <Mic className="h-4 w-4" />;
      case 'document': return <FileText className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getEvidenceTypeColor = (type: string) => {
    switch (type) {
      case 'image': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'video': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'audio': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'document': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 lg:ml-64 p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Evidence Management</h1>
              <p className="text-muted-foreground mt-1">
                Secure storage and verification of investigation evidence
              </p>
            </div>
            
            <Button>
              <Upload className="h-4 w-4 mr-2" />
              Upload Evidence
            </Button>
          </div>

          {/* Filters */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search evidence by filename, description, or mission..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <Select value={selectedMission} onValueChange={setSelectedMission}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="All Missions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Missions</SelectItem>
                      {missions?.missions?.map((mission: any) => (
                        <SelectItem key={mission.id} value={mission.id}>
                          {mission.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={evidenceType} onValueChange={setEvidenceType}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="image">Images</SelectItem>
                      <SelectItem value="video">Videos</SelectItem>
                      <SelectItem value="audio">Audio</SelectItem>
                      <SelectItem value="document">Documents</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Evidence Tabs */}
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Evidence</TabsTrigger>
              <TabsTrigger value="pending">Pending Review</TabsTrigger>
              <TabsTrigger value="verified">Verified</TabsTrigger>
              <TabsTrigger value="my-uploads">My Uploads</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-1/2 mb-4"></div>
                        <div className="h-3 bg-muted rounded w-full mb-2"></div>
                        <div className="h-3 bg-muted rounded w-2/3"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Mock Evidence Cards */}
                  <Card className="mission-card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          {getEvidenceIcon('image')}
                          <Badge className={getEvidenceTypeColor('image')}>
                            Image
                          </Badge>
                        </div>
                        <Badge className="status-verified">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      </div>
                      
                      <h3 className="font-semibold mb-2">surveillance_footage_001.jpg</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        High-resolution image from security camera showing suspect vehicle
                      </p>
                      
                      <div className="space-y-2 text-xs text-muted-foreground mb-4">
                        <div className="flex items-center justify-between">
                          <span>Mission:</span>
                          <span className="text-foreground">MP-2024-001</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Uploaded:</span>
                          <span className="text-foreground">2 hours ago</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Size:</span>
                          <span className="text-foreground">2.4 MB</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="mission-card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          {getEvidenceIcon('video')}
                          <Badge className={getEvidenceTypeColor('video')}>
                            Video
                          </Badge>
                        </div>
                        <Badge className="status-pending">
                          <Clock className="h-3 w-3 mr-1" />
                          Pending
                        </Badge>
                      </div>
                      
                      <h3 className="font-semibold mb-2">interview_recording.mp4</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Video interview with witness from missing person case
                      </p>
                      
                      <div className="space-y-2 text-xs text-muted-foreground mb-4">
                        <div className="flex items-center justify-between">
                          <span>Mission:</span>
                          <span className="text-foreground">MP-2024-005</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Uploaded:</span>
                          <span className="text-foreground">1 day ago</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Size:</span>
                          <span className="text-foreground">45.2 MB</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        {user.role === 'admin' && (
                          <Button variant="outline" size="sm" className="flex-1">
                            <Shield className="h-3 w-3 mr-1" />
                            Verify
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="mission-card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          {getEvidenceIcon('document')}
                          <Badge className={getEvidenceTypeColor('document')}>
                            Document
                          </Badge>
                        </div>
                        <Badge className="status-verified">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      </div>
                      
                      <h3 className="font-semibold mb-2">forensic_report.pdf</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Detailed forensic analysis report with findings and conclusions
                      </p>
                      
                      <div className="space-y-2 text-xs text-muted-foreground mb-4">
                        <div className="flex items-center justify-between">
                          <span>Mission:</span>
                          <span className="text-foreground">SV-2024-032</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Uploaded:</span>
                          <span className="text-foreground">3 days ago</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Size:</span>
                          <span className="text-foreground">1.8 MB</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {(!evidence || evidence.length === 0) && !isLoading && (
                <div className="text-center py-12">
                  <div className="mx-auto w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
                    <FileText className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No evidence found</h3>
                  <p className="text-muted-foreground mb-4">
                    No evidence matches your current search and filter criteria.
                  </p>
                  <Button>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Evidence
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="pending">
              <div className="text-center py-12">
                <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Pending Review</h3>
                <p className="text-muted-foreground">Evidence awaiting verification will appear here.</p>
              </div>
            </TabsContent>

            <TabsContent value="verified">
              <div className="text-center py-12">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Verified Evidence</h3>
                <p className="text-muted-foreground">Successfully verified evidence will appear here.</p>
              </div>
            </TabsContent>

            <TabsContent value="my-uploads">
              <div className="text-center py-12">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">My Uploads</h3>
                <p className="text-muted-foreground">Evidence you've uploaded will appear here.</p>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

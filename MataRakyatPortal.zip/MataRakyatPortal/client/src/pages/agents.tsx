import { AgentDirectory } from "@/components/agent/agent-directory";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Shield, MessageCircle, Globe } from "lucide-react";

export default function Agents() {
  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header dengan informasi platform */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <Users className="h-8 w-8 text-blue-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Direktori Agen Platform</h1>
              <p className="text-gray-400">Jaringan agen terpercaya dengan nama samaran untuk menjaga privasi</p>
            </div>
          </div>

          {/* Platform Social Media Info */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center justify-center gap-6">
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-4 w-4 text-blue-400" />
                  <span className="text-gray-300">Telegram:</span>
                  <Badge variant="outline" className="text-blue-400 border-blue-400">
                    @mata_rakyat_official
                  </Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-4 w-4 text-green-400" />
                  <span className="text-gray-300">WhatsApp:</span>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    +62-8XX-XXXX-XXXX
                  </Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <Globe className="h-4 w-4 text-purple-400" />
                  <span className="text-gray-300">Support:</span>
                  <Badge variant="outline" className="text-purple-400 border-purple-400">
                    support@matarakyat.local
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security Notice */}
          <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4">
            <div className="flex items-center space-x-2 text-yellow-400">
              <Shield className="h-5 w-5" />
              <span className="font-semibold">Keamanan & Privasi</span>
            </div>
            <p className="text-yellow-300 text-sm mt-2">
              Semua agen menggunakan nama samaran untuk melindungi identitas. Kontak langsung hanya tersedia melalui platform yang aman. 
              Admin dapat melihat informasi lengkap untuk keperluan verifikasi dan koordinasi.
            </p>
          </div>
        </div>

        {/* Agent Directory Component */}
        <AgentDirectory />

        {/* Footer Info */}
        <div className="text-center text-gray-400 text-sm space-y-2">
          <p>🛡️ Platform Mata Rakyat - Sistem Informasi dan Intel Rakyat</p>
          <p>⚠️ Platform ini hanya sebagai situs informasi dan tidak berkaitan dengan hukum</p>
          <p>📞 Untuk bantuan teknis hubungi support melalui kontak yang tersedia</p>
        </div>
      </div>
    </div>
  );
}
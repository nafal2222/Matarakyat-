import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Shield, 
  Award, 
  TrendingUp, 
  Settings, 
  Bell, 
  Lock,
  Camera,
  Save,
  Star,
  DollarSign,
  Clock,
  CheckCircle
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Profile() {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    missionUpdates: true,
    paymentAlerts: true,
    securityAlerts: true
  });

  // Mock data - in production this would come from API
  const profileStats = {
    completedMissions: 47,
    successRate: 94.5,
    totalEarnings: 15750000,
    rating: 4.8,
    reviewCount: 23,
    responseTime: "2 jam",
    memberSince: "Januari 2023"
  };

  const recentActivity = [
    {
      id: 1,
      type: "mission_completed",
      title: "Misi Pencarian Barang Hilang",
      description: "Berhasil menemukan dokumen penting di area Kemang",
      timestamp: "2 jam yang lalu",
      status: "completed"
    },
    {
      id: 2,
      type: "payment_received",
      title: "Pembayaran Diterima",
      description: "Rp 750.000 untuk misi #MR-2024-0156",
      timestamp: "5 jam yang lalu",
      status: "success"
    },
    {
      id: 3,
      type: "review_received",
      title: "Ulasan Baru",
      description: "Rating 5 bintang dari pemberi misi",
      timestamp: "1 hari yang lalu",
      status: "positive"
    }
  ];

  const badges = [
    { name: "Pelaksana Terpercaya", level: "Gold", icon: Shield },
    { name: "Pencari Ahli", level: "Silver", icon: Award },
    { name: "Respons Cepat", level: "Bronze", icon: Clock },
    { name: "Rating Tinggi", level: "Gold", icon: Star }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white">
            Profil Pengguna
          </h1>
          <p className="text-lg text-slate-300">
            Kelola informasi profil dan pengaturan akun Anda
          </p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 bg-slate-800 border-slate-700">
            <TabsTrigger value="profile" className="data-[state=active]:bg-teal-600">
              <User className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Profil</span>
            </TabsTrigger>
            <TabsTrigger value="stats" className="data-[state=active]:bg-teal-600">
              <TrendingUp className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Statistik</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-teal-600">
              <Settings className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Pengaturan</span>
            </TabsTrigger>
            <TabsTrigger value="activity" className="data-[state=active]:bg-teal-600">
              <Clock className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Aktivitas</span>
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <CardTitle className="text-white">Informasi Profil</CardTitle>
                  <Button 
                    onClick={() => setIsEditing(!isEditing)}
                    variant={isEditing ? "destructive" : "default"}
                    className={isEditing ? "" : "bg-teal-600 hover:bg-teal-700"}
                  >
                    {isEditing ? "Batal" : "Edit Profil"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col sm:flex-row items-center gap-6">
                  <div className="relative">
                    <Avatar className="w-24 h-24 sm:w-32 sm:h-32">
                      <AvatarImage src={user?.profileImageUrl || ""} />
                      <AvatarFallback className="text-2xl bg-teal-600">
                        {user?.firstName?.[0] || "U"}
                      </AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <Button size="sm" className="absolute bottom-0 right-0 rounded-full p-2 bg-teal-600">
                        <Camera className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="flex-1 space-y-4 w-full">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-slate-300">Nama Depan</Label>
                        <Input
                          id="firstName"
                          value={user?.firstName || ""}
                          disabled={!isEditing}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-slate-300">Nama Belakang</Label>
                        <Input
                          id="lastName"
                          value={user?.lastName || ""}
                          disabled={!isEditing}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-slate-300">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={user?.email || ""}
                        disabled={!isEditing}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio" className="text-slate-300">Bio</Label>
                      <Textarea
                        id="bio"
                        placeholder="Ceritakan tentang pengalaman dan keahlian Anda..."
                        disabled={!isEditing}
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-slate-300">Nomor Telepon</Label>
                        <Input
                          id="phone"
                          placeholder="+62 xxx xxxx xxxx"
                          disabled={!isEditing}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="location" className="text-slate-300">Lokasi</Label>
                        <Input
                          id="location"
                          placeholder="Jakarta, Indonesia"
                          disabled={!isEditing}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>

                    {isEditing && (
                      <Button className="bg-teal-600 hover:bg-teal-700">
                        <Save className="w-4 h-4 mr-2" />
                        Simpan Perubahan
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Badges */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Lencana & Pencapaian</CardTitle>
                <CardDescription className="text-slate-400">
                  Lencana yang Anda peroleh berdasarkan kinerja dan pencapaian
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {badges.map((badge, index) => (
                    <div key={index} className="flex flex-col items-center p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                      <badge.icon className="w-8 h-8 text-teal-400 mb-2" />
                      <h4 className="font-semibold text-white text-sm text-center">{badge.name}</h4>
                      <Badge 
                        variant={badge.level === "Gold" ? "default" : badge.level === "Silver" ? "secondary" : "outline"}
                        className="mt-1 text-xs"
                      >
                        {badge.level}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Misi Selesai</p>
                      <p className="text-2xl font-bold text-white">{profileStats.completedMissions}</p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Tingkat Sukses</p>
                      <p className="text-2xl font-bold text-white">{profileStats.successRate}%</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-teal-400" />
                  </div>
                  <Progress value={profileStats.successRate} className="mt-2" />
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Total Pendapatan</p>
                      <p className="text-2xl font-bold text-white">
                        Rp {profileStats.totalEarnings.toLocaleString()}
                      </p>
                    </div>
                    <DollarSign className="w-8 h-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Rating</p>
                      <div className="flex items-center gap-1">
                        <p className="text-2xl font-bold text-white">{profileStats.rating}</p>
                        <Star className="w-5 h-5 text-yellow-400 fill-current" />
                      </div>
                      <p className="text-xs text-slate-400">({profileStats.reviewCount} ulasan)</p>
                    </div>
                    <Award className="w-8 h-8 text-yellow-400" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Performa Bulanan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                  <p className="text-slate-400">Grafik performa akan ditampilkan di sini</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Pengaturan Notifikasi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Notifikasi Email</p>
                    <p className="text-slate-400 text-sm">Terima update melalui email</p>
                  </div>
                  <Switch 
                    checked={notifications.email}
                    onCheckedChange={(checked) => setNotifications({...notifications, email: checked})}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Notifikasi SMS</p>
                    <p className="text-slate-400 text-sm">Terima alert melalui SMS</p>
                  </div>
                  <Switch 
                    checked={notifications.sms}
                    onCheckedChange={(checked) => setNotifications({...notifications, sms: checked})}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Push Notification</p>
                    <p className="text-slate-400 text-sm">Notifikasi langsung di perangkat</p>
                  </div>
                  <Switch 
                    checked={notifications.push}
                    onCheckedChange={(checked) => setNotifications({...notifications, push: checked})}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Update Misi</p>
                    <p className="text-slate-400 text-sm">Pemberitahuan status misi</p>
                  </div>
                  <Switch 
                    checked={notifications.missionUpdates}
                    onCheckedChange={(checked) => setNotifications({...notifications, missionUpdates: checked})}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Alert Pembayaran</p>
                    <p className="text-slate-400 text-sm">Pemberitahuan transaksi</p>
                  </div>
                  <Switch 
                    checked={notifications.paymentAlerts}
                    onCheckedChange={(checked) => setNotifications({...notifications, paymentAlerts: checked})}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  Keamanan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full border-slate-600 text-slate-300">
                  Ubah Password
                </Button>
                <Button variant="outline" className="w-full border-slate-600 text-slate-300">
                  Aktifkan Two-Factor Authentication
                </Button>
                <Button variant="outline" className="w-full border-slate-600 text-slate-300">
                  Kelola Sesi Login
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Aktivitas Terbaru</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-4 p-4 bg-slate-700/30 rounded-lg">
                      <div className="flex-shrink-0 w-2 h-2 rounded-full bg-teal-400 mt-2"></div>
                      <div className="flex-1">
                        <h4 className="font-medium text-white">{activity.title}</h4>
                        <p className="text-slate-400 text-sm">{activity.description}</p>
                        <p className="text-slate-500 text-xs mt-1">{activity.timestamp}</p>
                      </div>
                      <Badge 
                        variant={activity.status === "completed" ? "default" : 
                                activity.status === "success" ? "default" : "secondary"}
                        className="text-xs"
                      >
                        {activity.status === "completed" ? "Selesai" :
                         activity.status === "success" ? "Berhasil" : "Positif"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/layout/navigation";
import { Sidebar } from "@/components/layout/sidebar";
import { MissionFilters } from "@/components/mission/mission-filters";
import { MissionCard } from "@/components/mission/mission-card";
import { Button } from "@/components/ui/button";
import { Plus, Grid, List } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import type { MissionFilters as MissionFiltersType } from "@/lib/types";

export default function Missions() {
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filters, setFilters] = useState<MissionFiltersType>({
    limit: 20,
    offset: 0
  });

  const { data: missionsData, isLoading } = useQuery({
    queryKey: ['/api/missions', filters],
  });

  const handleFilterChange = (newFilters: Partial<MissionFiltersType>) => {
    setFilters(prev => ({ ...prev, ...newFilters, offset: 0 }));
  };

  const loadMore = () => {
    setFilters(prev => ({
      ...prev,
      offset: (prev.offset || 0) + (prev.limit || 20)
    }));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 lg:ml-64 p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Missions</h1>
              <p className="text-muted-foreground mt-1">
                {user.role === 'mission_provider' 
                  ? 'Manage your posted missions and review proposals'
                  : 'Browse available missions and track your assignments'
                }
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center border border-border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
              
              {(user.role === 'mission_provider' || user.role === 'admin') && (
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Mission
                </Button>
              )}
            </div>
          </div>

          {/* Filters */}
          <MissionFilters 
            filters={filters} 
            onFilterChange={handleFilterChange}
            userRole={user.role}
          />

          {/* Mission Results */}
          <div className="mt-8">
            {isLoading ? (
              <div className={`grid gap-6 ${
                viewMode === 'grid' 
                  ? 'grid-cols-1 lg:grid-cols-2 xl:grid-cols-3' 
                  : 'grid-cols-1'
              }`}>
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-card rounded-xl p-6 animate-pulse">
                    <div className="h-6 bg-muted rounded w-3/4 mb-4"></div>
                    <div className="h-4 bg-muted rounded w-full mb-2"></div>
                    <div className="h-4 bg-muted rounded w-2/3 mb-4"></div>
                    <div className="space-y-2">
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                      <div className="h-3 bg-muted rounded w-1/3"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    {missionsData?.total || 0} missions found
                  </p>
                </div>
                
                <div className={`grid gap-6 ${
                  viewMode === 'grid' 
                    ? 'grid-cols-1 lg:grid-cols-2 xl:grid-cols-3' 
                    : 'grid-cols-1'
                }`}>
                  {missionsData?.missions?.map((mission: any) => (
                    <MissionCard 
                      key={mission.id} 
                      mission={mission} 
                      viewMode={viewMode}
                    />
                  ))}
                </div>

                {missionsData?.missions?.length === 0 && (
                  <div className="text-center py-12">
                    <div className="mx-auto w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
                      <Plus className="h-12 w-12 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">No missions found</h3>
                    <p className="text-muted-foreground mb-4">
                      {user.role === 'mission_provider'
                        ? "You haven't created any missions yet."
                        : "No missions match your current filters."
                      }
                    </p>
                    {user.role === 'mission_provider' && (
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Your First Mission
                      </Button>
                    )}
                  </div>
                )}

                {missionsData?.missions?.length > 0 && 
                 missionsData.missions.length < missionsData.total && (
                  <div className="text-center mt-8">
                    <Button variant="outline" onClick={loadMore}>
                      Load More Missions
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

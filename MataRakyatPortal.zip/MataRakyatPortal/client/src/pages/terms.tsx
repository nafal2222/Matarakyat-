import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Shield, FileText, Scale, Users, Clock } from "lucide-react";

export default function Terms() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-4">
            Syarat & Ketentuan
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Platform Mata Rakyat adalah sistem informasi yang bertujuan membantu masyarakat dalam melaporkan dan melacak berbagai kasus
          </p>
          <Badge variant="destructive" className="text-lg px-4 py-2">
            <AlertTriangle className="w-5 h-5 mr-2" />
            PENTING: Platform Informasi Saja - Bukan Layanan Hukum
          </Badge>
        </div>

        {/* Disclaimer Utama */}
        <Card className="bg-red-950/50 border-red-500/20">
          <CardHeader>
            <CardTitle className="text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6" />
              Pernyataan Penting
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-red-100">
            <p className="text-lg font-semibold">
              Platform Mata Rakyat adalah SISTEM INFORMASI dan BUKAN merupakan:
            </p>
            <ul className="list-disc list-inside space-y-2 text-red-200">
              <li>Lembaga penegak hukum resmi</li>
              <li>Organisasi kepolisian atau keamanan</li>
              <li>Badan investigasi berlisensi</li>
              <li>Penyedia layanan hukum atau pengacara</li>
              <li>Detektif swasta berlisensi</li>
            </ul>
            <p className="text-lg font-semibold text-red-300">
              Semua aktivitas di platform ini bersifat SUKARELA dan untuk tujuan INFORMASI saja.
            </p>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Syarat Umum */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-teal-300 flex items-center gap-2">
                <FileText className="w-6 h-6" />
                Syarat Umum Platform
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <div className="space-y-3">
                <h4 className="font-semibold text-white">1. Tujuan Platform</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Memfasilitasi pelaporan kasus orang hilang</li>
                  <li>Membantu pencarian barang hilang</li>
                  <li>Berbagi informasi target DPO (Daftar Pencarian Orang)</li>
                  <li>Koordinasi relawan untuk bantuan pencarian</li>
                </ul>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold text-white">2. Kewajiban Pengguna</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Memberikan informasi yang akurat dan benar</li>
                  <li>Tidak menyebarkan informasi palsu atau menyesatkan</li>
                  <li>Menghormati privasi dan keamanan semua pihak</li>
                  <li>Melaporkan ke pihak berwenang untuk kasus serius</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-white">3. Batasan Tanggung Jawab</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Platform tidak bertanggung jawab atas hasil pencarian</li>
                  <li>Tidak menjamin keberhasilan misi yang dilaporkan</li>
                  <li>Tidak bertanggung jawab atas tindakan pengguna</li>
                  <li>Informasi disediakan "apa adanya"</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Protokol Keamanan */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-teal-300 flex items-center gap-2">
                <Shield className="w-6 h-6" />
                Protokol Keamanan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-slate-300">
              <div className="space-y-3">
                <h4 className="font-semibold text-white">1. Keamanan Data</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Enkripsi data sensitif pengguna</li>
                  <li>Penyimpanan aman untuk bukti dan dokumentasi</li>
                  <li>Akses terbatas berdasarkan peran pengguna</li>
                  <li>Backup data berkala untuk mencegah kehilangan</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-white">2. Verifikasi Identitas</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Verifikasi wajib untuk pelapor misi</li>
                  <li>Konfirmasi identitas pelaksana misi</li>
                  <li>Sistem rating dan review transparan</li>
                  <li>Pemantauan aktivitas mencurigakan</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-white">3. Eskalasi ke Pihak Berwenang</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Laporan otomatis untuk kasus tindak pidana</li>
                  <li>Koordinasi dengan kepolisian setempat</li>
                  <li>Penyediaan bukti untuk investigasi resmi</li>
                  <li>Dukungan proses hukum yang sah</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Peraturan Sayembara */}
        <Card className="bg-amber-950/30 border-amber-500/20">
          <CardHeader>
            <CardTitle className="text-amber-300 flex items-center gap-2">
              <Scale className="w-6 h-6" />
              Peraturan Sistem Sayembara
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-amber-100">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold text-white">Pemberi Misi (Provider)</h4>
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li>Wajib memberikan informasi lengkap dan akurat</li>
                  <li>Menetapkan kompensasi yang wajar dan realistis</li>
                  <li>Menyediakan bukti pendukung yang valid</li>
                  <li>Melakukan pembayaran sesuai kesepakatan</li>
                  <li>Tidak boleh meminta tindakan ilegal</li>
                  <li>Bertanggung jawab atas keakuratan informasi</li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold text-white">Pelaksana Misi (Executor)</h4>
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li>Menggunakan metode legal dan etis</li>
                  <li>Menjaga kerahasiaan informasi sensitif</li>
                  <li>Memberikan laporan progress berkala</li>
                  <li>Menyediakan bukti hasil pencarian</li>
                  <li>Tidak melakukan tindakan intimidasi</li>
                  <li>Menghormati privasi semua pihak</li>
                </ul>
              </div>
            </div>

            <div className="bg-amber-900/30 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Sistem Escrow Payment</h4>
              <p className="text-sm">
                Dana akan ditahan dalam sistem escrow sampai misi selesai dan diverifikasi. 
                Pembayaran akan dirilis setelah konfirmasi dari pemberi misi dan validasi bukti.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Ketentuan Khusus Target DPO */}
        <Card className="bg-red-900/20 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-300 flex items-center gap-2">
              <Users className="w-6 h-6" />
              Ketentuan Khusus: Target DPO
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-red-100">
            <div className="bg-red-950/50 p-4 rounded-lg border border-red-500/30">
              <h4 className="font-bold text-white mb-3">PERINGATAN KHUSUS</h4>
              <p className="text-sm leading-relaxed">
                Kategori "Target DPO" hanya untuk berbagi informasi dan koordinasi pencarian. 
                <strong className="text-red-300"> DILARANG KERAS</strong> melakukan:
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h5 className="font-semibold text-white mb-2">Tindakan Terlarang:</h5>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Kekerasan fisik atau ancaman</li>
                  <li>Penangkapan atau penahanan</li>
                  <li>Intimidasi atau paksaan</li>
                  <li>Masuk properti tanpa izin</li>
                  <li>Mengambil tindakan hukum sendiri</li>
                </ul>
              </div>

              <div>
                <h5 className="font-semibold text-white mb-2">Tindakan yang Diizinkan:</h5>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Pengamatan dari jarak aman</li>
                  <li>Dokumentasi foto/video legal</li>
                  <li>Pelaporan lokasi ke pihak berwenang</li>
                  <li>Berbagi informasi dengan keluarga</li>
                  <li>Koordinasi dengan relawan pencarian</li>
                </ul>
              </div>
            </div>

            <div className="bg-red-950/50 p-4 rounded-lg">
              <p className="text-sm font-semibold">
                Jika target ditemukan, segera hubungi kepolisian setempat (110) dan berikan informasi melalui saluran resmi.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Peran dan Tanggung Jawab */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-teal-300 flex items-center gap-2">
              <Users className="w-6 h-6" />
              Peran dan Tanggung Jawab
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-slate-300">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <h4 className="font-semibold text-teal-300 mb-2">Admin</h4>
                <ul className="text-xs space-y-1">
                  <li>• Moderasi platform</li>
                  <li>• Verifikasi pengguna</li>
                  <li>• Resolusi sengketa</li>
                  <li>• Koordinasi dengan pihak berwenang</li>
                </ul>
              </div>

              <div className="bg-slate-700/50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-300 mb-2">Agent</h4>
                <ul className="text-xs space-y-1">
                  <li>• Membantu verifikasi misi</li>
                  <li>• Koordinasi lapangan</li>
                  <li>• Validasi bukti</li>
                  <li>• Komunikasi dengan keluarga</li>
                </ul>
              </div>

              <div className="bg-slate-700/50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-300 mb-2">Pemberi Misi</h4>
                <ul className="text-xs space-y-1">
                  <li>• Melaporkan kasus</li>
                  <li>• Menyediakan informasi</li>
                  <li>• Menetapkan kompensasi</li>
                  <li>• Verifikasi hasil</li>
                </ul>
              </div>

              <div className="bg-slate-700/50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-300 mb-2">Pelaksana Misi</h4>
                <ul className="text-xs space-y-1">
                  <li>• Melakukan pencarian</li>
                  <li>• Mengumpulkan bukti</li>
                  <li>• Melaporkan progress</li>
                  <li>• Menjaga etika</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Kontak Darurat */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-teal-300 flex items-center gap-2">
              <Clock className="w-6 h-6" />
              Kontak Darurat & Pelaporan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-300">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-red-950/30 p-4 rounded-lg text-center">
                <h4 className="font-bold text-red-300 mb-2">Polisi</h4>
                <p className="text-2xl font-bold text-white">110</p>
                <p className="text-xs">Keadaan darurat & tindak pidana</p>
              </div>

              <div className="bg-blue-950/30 p-4 rounded-lg text-center">
                <h4 className="font-bold text-blue-300 mb-2">Kominfo</h4>
                <p className="text-lg font-bold text-white">129</p>
                <p className="text-xs">Laporan konten ilegal</p>
              </div>

              <div className="bg-green-950/30 p-4 rounded-lg text-center">
                <h4 className="font-bold text-green-300 mb-2">Support Platform</h4>
                <p className="text-sm font-bold text-white">support@matarakyat.id</p>
                <p className="text-xs">Bantuan teknis platform</p>
              </div>
            </div>

            <div className="bg-slate-700/50 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Pelaporan Penyalahgunaan</h4>
              <p className="text-sm">
                Jika Anda menemukan penyalahgunaan platform, konten ilegal, atau aktivitas mencurigakan, 
                segera laporkan melalui fitur pelaporan dalam aplikasi atau hubungi tim support kami.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-slate-400 border-t border-slate-700 pt-8">
          <p className="text-sm">
            Dengan menggunakan platform Mata Rakyat, Anda menyetujui semua syarat dan ketentuan di atas.
          </p>
          <p className="text-xs mt-2">
            Terakhir diperbarui: {new Date().toLocaleDateString('id-ID', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </div>
      </div>
    </div>
  );
}
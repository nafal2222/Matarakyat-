import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Eye, EyeOff, LogIn, Users, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface LoginCredentials {
  email: string;
  password: string;
}

const DEMO_ACCOUNTS = [
  {
    email: 'admin@matarakyat.demo',
    password: 'admin123',
    role: 'Administrator',
    name: 'Admin Platform',
    description: 'Akses penuh: verifikasi misi, manajemen user, analytics',
    color: 'bg-red-500'
  },
  {
    email: 'agent@matarakyat.demo', 
    password: 'agent123',
    role: 'Agent',
    name: 'Budi Santoso',
    description: 'Koordinasi lapangan, validasi bukti, bantuan verifikasi',
    color: 'bg-blue-500'
  },
  {
    email: 'provider@matarakyat.demo',
    password: 'provider123', 
    role: 'Pemberi Misi',
    name: 'Siti Rahayu',
    description: 'Buat misi, monitor progress, kelola pembayaran',
    color: 'bg-green-500'
  },
  {
    email: 'executor@matarakyat.demo',
    password: 'executor123',
    role: 'Pelaksana Misi', 
    name: 'Agus Pratama',
    description: 'Ambil misi, upload bukti, terima pembayaran',
    color: 'bg-purple-500'
  }
];

export default function DemoLogin() {
  const [credentials, setCredentials] = useState<LoginCredentials>({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (creds: LoginCredentials) => {
      const res = await apiRequest("POST", "/api/demo/login", creds);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/demo/user"], data.user);
      toast({
        title: "Login Berhasil!",
        description: `Selamat datang, ${data.user.firstName}!`,
      });
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Login Gagal",
        description: error.message || "Email atau password salah",
        variant: "destructive",
      });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentials.email || !credentials.password) {
      toast({
        title: "Form Tidak Lengkap",
        description: "Silakan isi email dan password",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate(credentials);
  };

  const quickLogin = (account: typeof DEMO_ACCOUNTS[0]) => {
    setCredentials({
      email: account.email,
      password: account.password
    });
    loginMutation.mutate({
      email: account.email,
      password: account.password
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8">
        
        {/* Login Form */}
        <Card className="w-full max-w-md mx-auto lg:mx-0">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-teal-600 rounded-full flex items-center justify-center mb-4">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Demo Login</CardTitle>
            <CardDescription>
              Masuk ke Platform Mata Rakyat untuk mencoba semua fitur
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={credentials.email}
                  onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Masukkan email demo"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={credentials.password}
                    onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                    placeholder="Masukkan password"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-teal-600 hover:bg-teal-700"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  "Masuk..."
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Masuk
                  </>
                )}
              </Button>
            </form>

            <Alert className="mt-6">
              <Users className="h-4 w-4" />
              <AlertDescription>
                <strong>Mode Demo Aktif:</strong> Gunakan akun demo di sebelah kanan untuk mencoba berbagai role dan fitur platform.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Demo Accounts */}
        <div className="space-y-4">
          <div className="text-center lg:text-left">
            <h2 className="text-2xl font-bold text-white mb-2">Akun Demo Tersedia</h2>
            <p className="text-slate-300">Klik salah satu akun di bawah untuk login otomatis</p>
          </div>
          
          <div className="grid gap-4">
            {DEMO_ACCOUNTS.map((account, index) => (
              <Card 
                key={index}
                className="cursor-pointer transition-all hover:shadow-lg hover:scale-[1.02] bg-white/10 backdrop-blur border-white/20"
                onClick={() => quickLogin(account)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full ${account.color} flex items-center justify-center flex-shrink-0`}>
                      <span className="text-white font-bold text-lg">
                        {account.name.charAt(0)}
                      </span>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-white truncate">{account.name}</h3>
                        <span className="text-xs bg-white/20 text-white px-2 py-1 rounded-full">
                          {account.role}
                        </span>
                      </div>
                      <p className="text-sm text-slate-300 mt-1">{account.description}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-slate-400">
                        <span>📧 {account.email}</span>
                        <span>🔑 {account.password}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Alert className="bg-yellow-500/10 border-yellow-500/20">
            <AlertDescription className="text-yellow-200">
              <strong>Catatan:</strong> Ini adalah lingkungan demo. Data akan direset secara berkala. 
              Jangan gunakan informasi sensitif atau real.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
}
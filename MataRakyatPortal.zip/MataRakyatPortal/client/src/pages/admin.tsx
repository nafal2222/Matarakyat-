import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { 
  Shield, 
  Users, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Search, 
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  UserCheck,
  UserX,
  TrendingUp,
  DollarSign,
  MapPin,
  Calendar,
  Flag,
  Bell,
  Settings,
  Database,
  Activity
} from "lucide-react";

export default function Admin() {
  const [selectedTab, setSelectedTab] = useState("overview");
  const [selectedMission, setSelectedMission] = useState(null);

  // Mock data - dalam produksi ini akan datang dari API
  const dashboardStats = {
    totalMissions: 1247,
    pendingVerification: 23,
    activeUsers: 892,
    completedToday: 15,
    totalRevenue: 45780000,
    flaggedContent: 7
  };

  const pendingMissions = [
    {
      id: "MR-2024-0234",
      title: "Pencarian Anak Hilang - Jakarta Selatan",
      category: "missing_person",
      submitter: "Ibu Sarah Wijaya",
      location: "Jakarta Selatan",
      reward: 2000000,
      status: "pending_verification",
      submittedAt: "2024-01-20 14:30",
      priority: "urgent",
      description: "Anak perempuan usia 7 tahun hilang di area Kemang sejak kemarin sore"
    },
    {
      id: "MR-2024-0235",
      title: "Dokumen Penting Hilang",
      category: "lost_items",
      submitter: "Bpk. Ahmad Soekarno",
      location: "Bandung",
      reward: 500000,
      status: "pending_verification",
      submittedAt: "2024-01-20 15:45",
      priority: "standard",
      description: "Tas berisi dokumen perusahaan hilang di taksi online"
    },
    {
      id: "MR-2024-0236",
      title: "Target DPO - Kasus Penipuan",
      category: "investigation",
      submitter: "Tim Investigasi Legal",
      location: "Surabaya",
      reward: 5000000,
      status: "pending_verification",
      submittedAt: "2024-01-20 16:20",
      priority: "high",
      description: "Pencarian tersangka kasus penipuan investasi bodong"
    }
  ];

  const recentUsers = [
    {
      id: "USR-001",
      name: "Budi Santoso",
      email: "budi@email.com",
      role: "mission_executor",
      status: "active",
      joinedAt: "2024-01-15",
      completedMissions: 12,
      rating: 4.8
    },
    {
      id: "USR-002", 
      name: "Siti Rahayu",
      email: "siti@email.com",
      role: "mission_provider",
      status: "pending_verification",
      joinedAt: "2024-01-20",
      completedMissions: 0,
      rating: 0
    },
    {
      id: "USR-003",
      name: "Agus Pratama",
      email: "agus@email.com", 
      role: "agent",
      status: "suspended",
      joinedAt: "2024-01-10",
      completedMissions: 8,
      rating: 3.2
    }
  ];

  const flaggedContent = [
    {
      id: "FLAG-001",
      type: "mission",
      title: "Konten Mencurigakan dalam Misi",
      reporter: "Sistem Otomatis",
      reason: "Kata kunci berisiko tinggi terdeteksi",
      status: "under_review",
      createdAt: "2024-01-20 12:00"
    },
    {
      id: "FLAG-002",
      type: "user",
      title: "Aktivitas Pengguna Mencurigakan",
      reporter: "Agent007",
      reason: "Pola aktivitas tidak normal",
      status: "pending",
      createdAt: "2024-01-20 10:30"
    }
  ];

  const approveMission = (missionId: string) => {
    console.log(`Menyetujui misi: ${missionId}`);
    // Implementasi API call untuk menyetujui misi
  };

  const rejectMission = (missionId: string, reason: string) => {
    console.log(`Menolak misi: ${missionId}, Alasan: ${reason}`);
    // Implementasi API call untuk menolak misi
  };

  const suspendUser = (userId: string) => {
    console.log(`Menangguhkan pengguna: ${userId}`);
    // Implementasi API call untuk menangguhkan pengguna
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "bg-red-500";
      case "high": return "bg-orange-500";
      case "standard": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "missing_person": return <Users className="w-4 h-4" />;
      case "lost_items": return <Search className="w-4 h-4" />;
      case "investigation": return <Shield className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white flex items-center justify-center gap-3">
            <Shield className="w-8 h-8 sm:w-10 sm:h-10 text-red-400" />
            Dashboard Administrator
          </h1>
          <p className="text-lg text-slate-300">
            Kelola platform, verifikasi misi, dan monitor aktivitas pengguna
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Total Misi</p>
                  <p className="text-xl font-bold text-white">{dashboardStats.totalMissions}</p>
                </div>
                <FileText className="w-6 h-6 text-teal-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Perlu Verifikasi</p>
                  <p className="text-xl font-bold text-orange-400">{dashboardStats.pendingVerification}</p>
                </div>
                <Clock className="w-6 h-6 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Pengguna Aktif</p>
                  <p className="text-xl font-bold text-green-400">{dashboardStats.activeUsers}</p>
                </div>
                <Users className="w-6 h-6 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Selesai Hari Ini</p>
                  <p className="text-xl font-bold text-blue-400">{dashboardStats.completedToday}</p>
                </div>
                <CheckCircle className="w-6 h-6 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Total Revenue</p>
                  <p className="text-lg font-bold text-yellow-400">
                    Rp {(dashboardStats.totalRevenue / 1000000).toFixed(1)}M
                  </p>
                </div>
                <DollarSign className="w-6 h-6 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">Konten Ditandai</p>
                  <p className="text-xl font-bold text-red-400">{dashboardStats.flaggedContent}</p>
                </div>
                <Flag className="w-6 h-6 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="missions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 bg-slate-800 border-slate-700">
            <TabsTrigger value="missions" className="data-[state=active]:bg-red-600">
              <FileText className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Verifikasi Misi</span>
              <span className="sm:hidden">Misi</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-red-600">
              <Users className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Kelola Pengguna</span>
              <span className="sm:hidden">User</span>
            </TabsTrigger>
            <TabsTrigger value="flagged" className="data-[state=active]:bg-red-600">
              <Flag className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Konten Ditandai</span>
              <span className="sm:hidden">Flag</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-red-600">
              <TrendingUp className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Analitik</span>
              <span className="sm:hidden">Stats</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-red-600">
              <Settings className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Pengaturan</span>
              <span className="sm:hidden">Set</span>
            </TabsTrigger>
          </TabsList>

          {/* Mission Verification Tab */}
          <TabsContent value="missions" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-400" />
                  Misi Menunggu Verifikasi ({pendingMissions.length})
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Tinjau dan verifikasi misi yang baru disubmit oleh pengguna
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingMissions.map((mission) => (
                    <Card key={mission.id} className="bg-slate-700/50 border-slate-600">
                      <CardContent className="p-4">
                        <div className="flex flex-col lg:flex-row gap-4">
                          <div className="flex-1 space-y-3">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2">
                                {getCategoryIcon(mission.category)}
                                <h3 className="font-semibold text-white">{mission.title}</h3>
                                <Badge className={`${getPriorityColor(mission.priority)} text-white text-xs`}>
                                  {mission.priority === "urgent" ? "Darurat" : 
                                   mission.priority === "high" ? "Tinggi" : "Standar"}
                                </Badge>
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {mission.id}
                              </Badge>
                            </div>
                            
                            <p className="text-slate-300 text-sm">{mission.description}</p>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm text-slate-400">
                              <div className="flex items-center gap-1">
                                <Users className="w-3 h-3" />
                                {mission.submitter}
                              </div>
                              <div className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {mission.location}
                              </div>
                              <div className="flex items-center gap-1">
                                <DollarSign className="w-3 h-3" />
                                Rp {mission.reward.toLocaleString()}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-1 text-xs text-slate-500">
                              <Calendar className="w-3 h-3" />
                              Disubmit: {mission.submittedAt}
                            </div>
                          </div>
                          
                          <div className="flex flex-col gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline" className="border-slate-600">
                                  <Eye className="w-4 h-4 mr-2" />
                                  Detail
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle className="text-white">Detail Misi - {mission.id}</DialogTitle>
                                  <DialogDescription className="text-slate-400">
                                    Informasi lengkap misi untuk verifikasi
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 text-slate-300">
                                  <div>
                                    <Label className="text-slate-400">Judul Misi</Label>
                                    <p>{mission.title}</p>
                                  </div>
                                  <div>
                                    <Label className="text-slate-400">Deskripsi</Label>
                                    <p>{mission.description}</p>
                                  </div>
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label className="text-slate-400">Pembuat Misi</Label>
                                      <p>{mission.submitter}</p>
                                    </div>
                                    <div>
                                      <Label className="text-slate-400">Lokasi</Label>
                                      <p>{mission.location}</p>
                                    </div>
                                    <div>
                                      <Label className="text-slate-400">Kompensasi</Label>
                                      <p>Rp {mission.reward.toLocaleString()}</p>
                                    </div>
                                    <div>
                                      <Label className="text-slate-400">Prioritas</Label>
                                      <Badge className={`${getPriorityColor(mission.priority)} text-white`}>
                                        {mission.priority === "urgent" ? "Darurat" : 
                                         mission.priority === "high" ? "Tinggi" : "Standar"}
                                      </Badge>
                                    </div>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            
                            <Button 
                              size="sm" 
                              onClick={() => approveMission(mission.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Setujui
                            </Button>
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="destructive">
                                  <XCircle className="w-4 h-4 mr-2" />
                                  Tolak
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent className="bg-slate-800 border-slate-700">
                                <AlertDialogHeader>
                                  <AlertDialogTitle className="text-white">Tolak Misi</AlertDialogTitle>
                                  <AlertDialogDescription className="text-slate-400">
                                    Apakah Anda yakin ingin menolak misi ini? Berikan alasan penolakan.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <div className="space-y-2">
                                  <Label className="text-slate-400">Alasan Penolakan</Label>
                                  <Textarea 
                                    placeholder="Masukkan alasan penolakan misi..."
                                    className="bg-slate-700 border-slate-600 text-white"
                                  />
                                </div>
                                <AlertDialogFooter>
                                  <AlertDialogCancel className="bg-slate-700 text-white border-slate-600">
                                    Batal
                                  </AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={() => rejectMission(mission.id, "Alasan dari admin")}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Tolak Misi
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Manajemen Pengguna</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700">
                      <TableHead className="text-slate-400">Pengguna</TableHead>
                      <TableHead className="text-slate-400">Peran</TableHead>
                      <TableHead className="text-slate-400">Status</TableHead>
                      <TableHead className="text-slate-400">Misi Selesai</TableHead>
                      <TableHead className="text-slate-400">Rating</TableHead>
                      <TableHead className="text-slate-400">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentUsers.map((user) => (
                      <TableRow key={user.id} className="border-slate-700">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="text-xs bg-teal-600">
                                {user.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-white font-medium">{user.name}</p>
                              <p className="text-slate-400 text-xs">{user.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {user.role === "mission_executor" ? "Pelaksana" :
                             user.role === "mission_provider" ? "Pemberi Misi" : "Agent"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={user.status === "active" ? "default" : 
                                    user.status === "pending_verification" ? "secondary" : "destructive"}
                            className="text-xs"
                          >
                            {user.status === "active" ? "Aktif" :
                             user.status === "pending_verification" ? "Menunggu" : "Ditangguhkan"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-slate-300">{user.completedMissions}</TableCell>
                        <TableCell className="text-slate-300">
                          {user.rating > 0 ? user.rating.toFixed(1) : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {user.status === "pending_verification" && (
                              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                <UserCheck className="w-3 h-3" />
                              </Button>
                            )}
                            {user.status === "active" && (
                              <Button 
                                size="sm" 
                                variant="destructive"
                                onClick={() => suspendUser(user.id)}
                              >
                                <UserX className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Flagged Content Tab */}
          <TabsContent value="flagged" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Flag className="w-5 h-5 text-red-400" />
                  Konten yang Ditandai
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {flaggedContent.map((item) => (
                    <Card key={item.id} className="bg-slate-700/50 border-slate-600">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-medium text-white">{item.title}</h3>
                            <p className="text-slate-400 text-sm">Dilaporkan oleh: {item.reporter}</p>
                            <p className="text-slate-300 text-sm">Alasan: {item.reason}</p>
                            <p className="text-slate-500 text-xs">{item.createdAt}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="border-slate-600">
                              <Eye className="w-4 h-4 mr-2" />
                              Tinjau
                            </Button>
                            <Button size="sm" className="bg-green-600 hover:bg-green-700">
                              Setujui
                            </Button>
                            <Button size="sm" variant="destructive">
                              Tolak
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Statistik Bulanan</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                    <p className="text-slate-400">Grafik aktivitas bulanan</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Distribusi Kategori Misi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                    <p className="text-slate-400">Chart kategori misi</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Pengaturan Platform</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Button variant="outline" className="border-slate-600 text-slate-300">
                    <Database className="w-4 h-4 mr-2" />
                    Backup Database
                  </Button>
                  <Button variant="outline" className="border-slate-600 text-slate-300">
                    <Activity className="w-4 h-4 mr-2" />
                    Log Aktivitas
                  </Button>
                  <Button variant="outline" className="border-slate-600 text-slate-300">
                    <Bell className="w-4 h-4 mr-2" />
                    Konfigurasi Notifikasi
                  </Button>
                  <Button variant="outline" className="border-slate-600 text-slate-300">
                    <Settings className="w-4 h-4 mr-2" />
                    Pengaturan Umum
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Bell, Shield, Globe, Palette, Database, Users } from "lucide-react";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: false,
      sms: true
    },
    privacy: {
      profileVisible: true,
      showLocation: false,
      showStats: true
    },
    appearance: {
      theme: "dark",
      language: "id"
    },
    platform: {
      maintenanceMode: false,
      registrationOpen: true,
      maxMissions: 100
    }
  });

  const handleSave = () => {
    toast({
      title: "Pengaturan Disimpan",
      description: "Semua perubahan telah berhasil disimpan.",
    });
  };

  const isAdmin = user?.role === 'admin';

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-blue-500/10 rounded-lg">
          <Shield className="h-6 w-6 text-blue-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Pengaturan Platform</h1>
          <p className="text-gray-400">Kelola preferensi dan konfigurasi sistem</p>
        </div>
      </div>

      <div className="grid gap-6">
        {/* Notifikasi */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Bell className="h-5 w-5 text-blue-400" />
              <span>Notifikasi</span>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Atur preferensi pemberitahuan Anda
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Email Notifikasi</Label>
                <p className="text-sm text-gray-400">Terima notifikasi melalui email</p>
              </div>
              <Switch 
                checked={settings.notifications.email}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, email: checked }
                  }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Push Notifikasi</Label>
                <p className="text-sm text-gray-400">Notifikasi langsung di browser</p>
              </div>
              <Switch 
                checked={settings.notifications.push}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, push: checked }
                  }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">SMS Notifikasi</Label>
                <p className="text-sm text-gray-400">Notifikasi melalui SMS untuk misi penting</p>
              </div>
              <Switch 
                checked={settings.notifications.sms}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, sms: checked }
                  }))
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* Privasi */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Shield className="h-5 w-5 text-green-400" />
              <span>Privasi & Keamanan</span>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Kontrol visibilitas profil dan data pribadi
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Profil Publik</Label>
                <p className="text-sm text-gray-400">Izinkan orang lain melihat profil Anda</p>
              </div>
              <Switch 
                checked={settings.privacy.profileVisible}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    privacy: { ...prev.privacy, profileVisible: checked }
                  }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Tampilkan Lokasi</Label>
                <p className="text-sm text-gray-400">Perlihatkan lokasi pada profil</p>
              </div>
              <Switch 
                checked={settings.privacy.showLocation}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    privacy: { ...prev.privacy, showLocation: checked }
                  }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Statistik Publik</Label>
                <p className="text-sm text-gray-400">Tampilkan rating dan statistik misi</p>
              </div>
              <Switch 
                checked={settings.privacy.showStats}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({
                    ...prev,
                    privacy: { ...prev.privacy, showStats: checked }
                  }))
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* Tampilan */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Palette className="h-5 w-5 text-purple-400" />
              <span>Tampilan & Bahasa</span>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Personalisasi antarmuka platform
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label className="text-white">Tema</Label>
              <Select value={settings.appearance.theme} onValueChange={(value) => 
                setSettings(prev => ({
                  ...prev,
                  appearance: { ...prev.appearance, theme: value }
                }))
              }>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="dark">Mode Gelap</SelectItem>
                  <SelectItem value="light">Mode Terang</SelectItem>
                  <SelectItem value="auto">Otomatis</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label className="text-white">Bahasa</Label>
              <Select value={settings.appearance.language} onValueChange={(value) => 
                setSettings(prev => ({
                  ...prev,
                  appearance: { ...prev.appearance, language: value }
                }))
              }>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="id">Bahasa Indonesia</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Pengaturan Admin */}
        {isAdmin && (
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-white">
                <Database className="h-5 w-5 text-red-400" />
                <span>Pengaturan Platform</span>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Konfigurasi sistem untuk administrator
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Mode Maintenance</Label>
                  <p className="text-sm text-gray-400">Aktifkan untuk pemeliharaan sistem</p>
                </div>
                <Switch 
                  checked={settings.platform.maintenanceMode}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      platform: { ...prev.platform, maintenanceMode: checked }
                    }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Registrasi Terbuka</Label>
                  <p className="text-sm text-gray-400">Izinkan pendaftaran pengguna baru</p>
                </div>
                <Switch 
                  checked={settings.platform.registrationOpen}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      platform: { ...prev.platform, registrationOpen: checked }
                    }))
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label className="text-white">Maksimal Misi Aktif</Label>
                <Input
                  type="number"
                  value={settings.platform.maxMissions}
                  onChange={(e) => 
                    setSettings(prev => ({
                      ...prev,
                      platform: { ...prev.platform, maxMissions: parseInt(e.target.value) }
                    }))
                  }
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tombol Simpan */}
        <div className="flex justify-end space-x-4">
          <Button 
            variant="outline" 
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Reset
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Simpan Pengaturan
          </Button>
        </div>
      </div>
    </div>
  );
}
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, Shield, Search, Clock, Award, Users, AlertTriangle, FileText, ChevronRight, MapPin, Phone, Mail } from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-teal-900/20 via-slate-900 to-blue-900/20"></div>
        <div className="relative z-10">
          {/* Navigation */}
          <nav className="border-b border-slate-700 bg-slate-900/95 backdrop-blur">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col sm:flex-row justify-between items-center h-auto sm:h-16 py-4 sm:py-0 gap-4 sm:gap-0">
                <div className="flex items-center space-x-2">
                  <Eye className="h-8 w-8 text-teal-400" />
                  <div>
                    <span className="text-xl font-bold text-white">Mata Rakyat</span>
                    <p className="text-xs text-slate-400 hidden sm:block">Platform Informasi Pencarian</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 sm:space-x-4">
                  <Link href="/terms">
                    <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                      <FileText className="w-4 h-4 mr-2" />
                      <span className="hidden sm:inline">Syarat & Ketentuan</span>
                      <span className="sm:hidden">S&K</span>
                    </Button>
                  </Link>
                  <Button onClick={() => window.location.href = '/api/login'} className="bg-teal-600 hover:bg-teal-700">
                    Masuk
                  </Button>
                </div>
              </div>
            </div>
          </nav>

          {/* Hero Content */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
            <div className="text-center">
              <Badge variant="destructive" className="mb-6 text-sm px-4 py-2">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Platform Informasi - Bukan Layanan Hukum
              </Badge>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white">
                Platform Pencarian
                <br />
                <span className="text-teal-400">Mata Rakyat</span>
              </h1>
              <p className="text-lg sm:text-xl text-slate-300 mb-8 max-w-3xl mx-auto leading-relaxed">
                Menghubungkan masyarakat untuk melaporkan orang hilang, barang hilang, dan koordinasi pencarian 
                melalui platform informasi yang aman dan kolaboratif dengan sistem pembayaran escrow.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button size="lg" onClick={() => window.location.href = '/api/login'} className="w-full sm:w-auto bg-teal-600 hover:bg-teal-700">
                  Mulai Sekarang
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
                <Link href="/terms">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto border-slate-600 text-slate-300 hover:bg-slate-800">
                    Baca Ketentuan
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 sm:py-20 bg-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-white">Mengapa Pilih Mata Rakyat?</h2>
            <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto">
              Platform informasi dengan keamanan tingkat profesional untuk semua kebutuhan pencarian dan koordinasi Anda
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Shield className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Pembayaran Escrow Aman</CardTitle>
                <CardDescription className="text-slate-300">
                  Pembayaran dilindungi dalam sistem escrow sampai misi selesai dan terverifikasi
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Search className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Manajemen Misi Lengkap</CardTitle>
                <CardDescription className="text-slate-300">
                  Pengelolaan siklus lengkap dari pembuatan hingga verifikasi dengan pelacakan real-time
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Clock className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Update Real-time</CardTitle>
                <CardDescription className="text-slate-300">
                  Update status langsung, notifikasi, dan komunikasi antar semua pihak
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Award className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Jaminan Kualitas</CardTitle>
                <CardDescription className="text-slate-300">
                  Sistem rating, ulasan, dan proses verifikasi untuk memastikan hasil berkualitas tinggi
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Users className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Platform Multi-Peran</CardTitle>
                <CardDescription className="text-slate-300">
                  Dukungan untuk admin, agen, pemberi misi, dan pelaksana misi
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 transition-colors">
              <CardHeader>
                <Eye className="h-8 sm:h-10 w-8 sm:w-10 text-teal-400 mb-4" />
                <CardTitle className="text-white text-lg">Manajemen Bukti</CardTitle>
                <CardDescription className="text-slate-300">
                  Upload, penyimpanan, dan verifikasi bukti investigasi yang aman
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="py-16 sm:py-20 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-white">Kategori Misi</h2>
            <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto">
              Berbagai jenis misi pencarian yang dapat dilaporkan dan dikerjakan melalui platform
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-red-900/30 to-red-800/20 border-red-700/30 hover:border-red-600/50 transition-colors">
              <CardHeader>
                <MapPin className="h-8 w-8 text-red-400 mb-4" />
                <CardTitle className="text-white">Orang Hilang</CardTitle>
                <CardDescription className="text-red-100">
                  Pencarian anggota keluarga, teman, atau orang yang dilaporkan hilang
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/20 border-blue-700/30 hover:border-blue-600/50 transition-colors">
              <CardHeader>
                <Search className="h-8 w-8 text-blue-400 mb-4" />
                <CardTitle className="text-white">Barang Hilang</CardTitle>
                <CardDescription className="text-blue-100">
                  Pencarian barang berharga, dokumen penting, atau properti yang hilang
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gradient-to-br from-amber-900/30 to-amber-800/20 border-amber-700/30 hover:border-amber-600/50 transition-colors">
              <CardHeader>
                <Eye className="h-8 w-8 text-amber-400 mb-4" />
                <CardTitle className="text-white">Target DPO</CardTitle>
                <CardDescription className="text-amber-100">
                  Pencarian target Daftar Pencarian Orang (DPO) dengan protokol khusus
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="py-16 sm:py-20 bg-slate-800/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-amber-900/20 border border-amber-700/30 rounded-lg p-6 sm:p-8">
            <div className="flex items-start gap-4">
              <AlertTriangle className="h-6 w-6 text-amber-400 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-amber-300 mb-2">Penting untuk Diketahui</h3>
                <p className="text-amber-100 mb-4">
                  Platform Mata Rakyat adalah sistem informasi untuk membantu koordinasi pencarian dan pelaporan. 
                  Kami BUKAN lembaga penegak hukum dan tidak memiliki kewenangan hukum.
                </p>
                <ul className="text-sm text-amber-200 space-y-1">
                  <li>• Untuk kasus darurat, segera hubungi Polisi (110)</li>
                  <li>• Platform ini hanya memfasilitasi koordinasi dan berbagi informasi</li>
                  <li>• Semua aktivitas harus mematuhi hukum yang berlaku</li>
                  <li>• Verifikasi dengan pihak berwenang untuk kasus serius</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 sm:py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-white">Siap untuk Memulai?</h2>
          <p className="text-slate-300 text-base sm:text-lg mb-8 max-w-2xl mx-auto">
            Bergabunglah dengan ribuan pengguna yang menggunakan Mata Rakyat untuk koordinasi pencarian yang aman dan efisien.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => window.location.href = '/api/login'} className="bg-teal-600 hover:bg-teal-700">
              Mulai Misi Pertama Anda
            </Button>
            <Link href="/terms">
              <Button variant="outline" size="lg" className="border-slate-600 text-slate-300 hover:bg-slate-800">
                Pelajari Ketentuan
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="py-12 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Phone className="h-8 w-8 text-red-400 mb-2" />
              <h4 className="font-semibold text-white">Darurat</h4>
              <p className="text-2xl font-bold text-red-300">110</p>
              <p className="text-xs text-slate-400">Kepolisian</p>
            </div>
            
            <div className="flex flex-col items-center">
              <Mail className="h-8 w-8 text-teal-400 mb-2" />
              <h4 className="font-semibold text-white">Support</h4>
              <p className="text-sm font-medium text-teal-300">support@matarakyat.id</p>
              <p className="text-xs text-slate-400">Bantuan Platform</p>
            </div>
            
            <div className="flex flex-col items-center">
              <FileText className="h-8 w-8 text-blue-400 mb-2" />
              <h4 className="font-semibold text-white">Kominfo</h4>
              <p className="text-lg font-bold text-blue-300">129</p>
              <p className="text-xs text-slate-400">Laporan Konten</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-700 py-8 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-2">
              <Eye className="h-6 w-6 text-teal-400" />
              <div>
                <span className="font-semibold text-white">Mata Rakyat</span>
                <p className="text-xs text-slate-400">Platform Informasi Pencarian</p>
              </div>
            </div>
            <div className="text-center sm:text-right">
              <p className="text-slate-400 text-sm">
                © 2024 Mata Rakyat. Platform informasi pencarian.
              </p>
              <p className="text-xs text-slate-500">
                Hanya untuk tujuan informasi - bukan layanan hukum
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, X, SlidersHorizontal } from "lucide-react";
import { MISSION_CATEGORIES, MISSION_STATUSES, MISSION_PRIORITIES } from "@/lib/types";
import type { MissionFilters as MissionFiltersType } from "@/lib/types";

interface MissionFiltersProps {
  filters: MissionFiltersType;
  onFilterChange: (filters: Partial<MissionFiltersType>) => void;
  userRole: string;
}

export function MissionFilters({ filters, onFilterChange, userRole }: MissionFiltersProps) {
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);

  const handleSearchChange = (value: string) => {
    onFilterChange({ search: value });
  };

  const handleStatusChange = (status: string, checked: boolean) => {
    const currentStatuses = filters.status || [];
    const newStatuses = checked 
      ? [...currentStatuses, status]
      : currentStatuses.filter(s => s !== status);
    
    onFilterChange({ status: newStatuses.length > 0 ? newStatuses : undefined });
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    const currentCategories = filters.category || [];
    const newCategories = checked 
      ? [...currentCategories, category]
      : currentCategories.filter(c => c !== category);
    
    onFilterChange({ category: newCategories.length > 0 ? newCategories : undefined });
  };

  const handlePriorityChange = (priority: string, checked: boolean) => {
    const currentPriorities = filters.priority || [];
    const newPriorities = checked 
      ? [...currentPriorities, priority]
      : currentPriorities.filter(p => p !== priority);
    
    onFilterChange({ priority: newPriorities.length > 0 ? newPriorities : undefined });
  };

  const clearFilters = () => {
    onFilterChange({ 
      search: undefined, 
      status: undefined, 
      category: undefined, 
      priority: undefined,
      myMissions: undefined 
    });
  };

  const activeFilterCount = [
    filters.search,
    filters.status?.length,
    filters.category?.length,
    filters.priority?.length,
    filters.myMissions
  ].filter(Boolean).length;

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
          {/* Search Input */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search missions by ID, location, or description..."
                value={filters.search || ''}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {/* Quick Filters */}
          <div className="flex flex-wrap gap-3">
            {/* My Missions Toggle */}
            {(userRole === 'mission_executor' || userRole === 'agent') && (
              <Button
                variant={filters.myMissions ? "default" : "outline"}
                size="sm"
                onClick={() => onFilterChange({ myMissions: !filters.myMissions })}
              >
                My Missions
              </Button>
            )}

            {/* Status Quick Filter */}
            <Select
              value={filters.status?.[0] || "all"}
              onValueChange={(value) => {
                if (value === "all") {
                  onFilterChange({ status: undefined });
                } else {
                  onFilterChange({ status: [value] });
                }
              }}
            >
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {MISSION_STATUSES.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Category Quick Filter */}
            <Select
              value={filters.category?.[0] || "all"}
              onValueChange={(value) => {
                if (value === "all") {
                  onFilterChange({ category: undefined });
                } else {
                  onFilterChange({ category: [value] });
                }
              }}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {MISSION_CATEGORIES.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Advanced Filters */}
            <Popover open={isAdvancedOpen} onOpenChange={setIsAdvancedOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Filters
                  {activeFilterCount > 0 && (
                    <Badge className="ml-2 h-5 w-5 flex items-center justify-center p-0 text-xs">
                      {activeFilterCount}
                    </Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" align="end">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Advanced Filters</h4>
                    {activeFilterCount > 0 && (
                      <Button variant="ghost" size="sm" onClick={clearFilters}>
                        Clear all
                      </Button>
                    )}
                  </div>

                  {/* Status Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Status</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {MISSION_STATUSES.map((status) => (
                        <div key={status.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`status-${status.value}`}
                            checked={filters.status?.includes(status.value) || false}
                            onCheckedChange={(checked) => 
                              handleStatusChange(status.value, checked as boolean)
                            }
                          />
                          <Label 
                            htmlFor={`status-${status.value}`}
                            className="text-sm"
                          >
                            {status.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Category Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Category</Label>
                    <div className="space-y-2">
                      {MISSION_CATEGORIES.map((category) => (
                        <div key={category.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`category-${category.value}`}
                            checked={filters.category?.includes(category.value) || false}
                            onCheckedChange={(checked) => 
                              handleCategoryChange(category.value, checked as boolean)
                            }
                          />
                          <Label 
                            htmlFor={`category-${category.value}`}
                            className="text-sm"
                          >
                            {category.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Priority Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Priority</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {MISSION_PRIORITIES.map((priority) => (
                        <div key={priority.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`priority-${priority.value}`}
                            checked={filters.priority?.includes(priority.value) || false}
                            onCheckedChange={(checked) => 
                              handlePriorityChange(priority.value, checked as boolean)
                            }
                          />
                          <Label 
                            htmlFor={`priority-${priority.value}`}
                            className="text-sm"
                          >
                            {priority.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* Active Filters */}
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-border">
            {filters.search && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Search: {filters.search}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => handleSearchChange('')}
                />
              </Badge>
            )}
            
            {filters.status?.map((status) => (
              <Badge key={status} variant="secondary" className="flex items-center gap-1">
                {MISSION_STATUSES.find(s => s.value === status)?.label}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => handleStatusChange(status, false)}
                />
              </Badge>
            ))}
            
            {filters.category?.map((category) => (
              <Badge key={category} variant="secondary" className="flex items-center gap-1">
                {MISSION_CATEGORIES.find(c => c.value === category)?.label}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => handleCategoryChange(category, false)}
                />
              </Badge>
            ))}
            
            {filters.priority?.map((priority) => (
              <Badge key={priority} variant="secondary" className="flex items-center gap-1">
                {MISSION_PRIORITIES.find(p => p.value === priority)?.label}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => handlePriorityChange(priority, false)}
                />
              </Badge>
            ))}

            {filters.myMissions && (
              <Badge variant="secondary" className="flex items-center gap-1">
                My Missions
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => onFilterChange({ myMissions: false })}
                />
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

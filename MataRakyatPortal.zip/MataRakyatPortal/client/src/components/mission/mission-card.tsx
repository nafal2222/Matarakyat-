import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MapPin, 
  Clock, 
  User, 
  Eye, 
  Edit, 
  Plus,
  DollarSign,
  Calendar,
  AlertTriangle
} from "lucide-react";
import { MISSION_STATUSES, MISSION_PRIORITIES } from "@/lib/types";

interface MissionCardProps {
  mission: {
    id: string;
    title: string;
    description: string;
    category: string;
    priority: string;
    status: string;
    location: string;
    budget: string;
    deadline: string;
    providerId: string;
    assignedTo?: string;
    isUrgent: boolean;
    createdAt: string;
  };
  viewMode?: 'grid' | 'list';
  compact?: boolean;
}

export function MissionCard({ mission, viewMode = 'grid', compact = false }: MissionCardProps) {
  const statusConfig = MISSION_STATUSES.find(s => s.value === mission.status);
  const priorityConfig = MISSION_PRIORITIES.find(p => p.value === mission.priority);
  
  const formatDeadline = (deadline: string) => {
    const date = new Date(deadline);
    const now = new Date();
    const diffTime = date.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return 'Overdue';
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `${diffDays} days left`;
  };

  const isOverdue = new Date(mission.deadline) < new Date();

  if (viewMode === 'list') {
    return (
      <Card className="mission-card-hover">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h3 className="text-lg font-semibold">{mission.title}</h3>
                <Badge className={`status-${mission.status}`}>
                  {statusConfig?.label}
                </Badge>
                {mission.isUrgent && (
                  <Badge variant="destructive" className="animate-pulse">
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Urgent
                  </Badge>
                )}
              </div>
              
              <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                {mission.description}
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 text-primary mr-2" />
                  <span className="text-muted-foreground">{mission.location}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="h-4 w-4 text-primary mr-2" />
                  <span className="text-muted-foreground">${mission.budget}</span>
                </div>
                <div className="flex items-center">
                  <Clock className={`h-4 w-4 mr-2 ${isOverdue ? 'text-destructive' : 'text-primary'}`} />
                  <span className={isOverdue ? 'text-destructive' : 'text-muted-foreground'}>
                    {formatDeadline(mission.deadline)}
                  </span>
                </div>
                <div className="flex items-center">
                  <User className="h-4 w-4 text-primary mr-2" />
                  <span className="text-muted-foreground">
                    {mission.assignedTo ? 'Assigned' : 'Unassigned'}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-2 ml-4">
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mission-card-hover overflow-hidden">
      <div className="relative">
        <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-2">
              {mission.category === 'missing_person' && '👤'}
              {mission.category === 'surveillance' && '📹'}
              {mission.category === 'lost_items' && '🔍'}
              {mission.category === 'investigation' && '🕵️'}
              {mission.category === 'background_check' && '📋'}
              {mission.category === 'security' && '🛡️'}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">
              {mission.category.replace('_', ' ')}
            </p>
          </div>
        </div>
        
        <div className="absolute top-4 left-4">
          <Badge className={`priority-${mission.priority} bg-${priorityConfig?.color}-500/20 text-${priorityConfig?.color}-400 border-${priorityConfig?.color}-500/30`}>
            {priorityConfig?.label}
          </Badge>
        </div>
        
        <div className="absolute top-4 right-4">
          <Badge variant="secondary" className="bg-black/50 text-white">
            ${mission.budget}
          </Badge>
        </div>

        {mission.isUrgent && (
          <div className="absolute top-12 left-4">
            <Badge variant="destructive" className="animate-pulse">
              <AlertTriangle className="h-3 w-3 mr-1" />
              Urgent
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className={`font-semibold ${compact ? 'text-base' : 'text-lg'}`}>
            {mission.title}
          </h3>
          <span className="text-xs text-muted-foreground">
            #{mission.id.slice(0, 8)}
          </span>
        </div>
        
        <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
          {mission.description}
        </p>
        
        <div className="space-y-3 mb-4">
          <div className="flex items-center text-sm">
            <MapPin className="h-4 w-4 text-primary mr-2" />
            <span className="text-muted-foreground">{mission.location}</span>
          </div>
          <div className="flex items-center text-sm">
            <Clock className={`h-4 w-4 mr-2 ${isOverdue ? 'text-destructive' : 'text-primary'}`} />
            <span className={isOverdue ? 'text-destructive' : 'text-muted-foreground'}>
              {formatDeadline(mission.deadline)}
            </span>
          </div>
          <div className="flex items-center text-sm">
            <User className="h-4 w-4 text-primary mr-2" />
            <span className="text-muted-foreground">
              {mission.assignedTo ? 'Assigned' : 'Available'}
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full bg-${statusConfig?.color}-500`}></div>
            <span className="text-sm text-muted-foreground">
              {statusConfig?.label}
            </span>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" title="View Details">
              <Eye className="h-4 w-4" />
            </Button>
            {mission.status === 'pending' && !mission.assignedTo ? (
              <Button size="sm" title="Accept Mission">
                <Plus className="h-4 w-4" />
              </Button>
            ) : (
              <Button variant="outline" size="sm" title="Update Status">
                <Edit className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, Search, CheckCircle, Clock, DollarSign } from "lucide-react";
import type { DashboardStats } from "@/lib/types";

interface StatsOverviewProps {
  stats?: DashboardStats;
  isLoading: boolean;
}

export function StatsOverview({ stats, isLoading }: StatsOverviewProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="h-10 w-10 rounded-lg" />
              </div>
              <Skeleton className="h-4 w-24 mt-4" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-muted-foreground">
              <Search className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">No data available</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statCards = [
    {
      title: "Active Missions",
      value: stats.activeMissions,
      icon: Search,
      iconColor: "text-primary",
      bgColor: "bg-primary/20",
      trend: { value: 12, isPositive: true, period: "from last month" }
    },
    {
      title: "Completed Today",
      value: stats.completedToday,
      icon: CheckCircle,
      iconColor: "text-green-500",
      bgColor: "bg-green-500/20",
      trend: { value: 5, isPositive: true, period: "from yesterday" }
    },
    {
      title: "Pending Review",
      value: stats.pendingReview,
      icon: Clock,
      iconColor: "text-yellow-500",
      bgColor: "bg-yellow-500/20",
      trend: { value: 3, isPositive: false, period: "from last week" }
    },
    {
      title: "Total Earnings",
      value: `$${parseFloat(stats.totalEarnings).toLocaleString()}`,
      icon: DollarSign,
      iconColor: "text-accent",
      bgColor: "bg-accent/20",
      trend: { value: 18, isPositive: true, period: "from last month" }
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        const TrendIcon = stat.trend.isPositive ? TrendingUp : TrendingDown;
        
        return (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <Icon className={`${stat.iconColor} h-6 w-6`} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-sm">
                <TrendIcon className={`h-4 w-4 mr-1 ${
                  stat.trend.isPositive ? 'text-green-500' : 'text-red-500'
                }`} />
                <span className={`${
                  stat.trend.isPositive ? 'text-green-500' : 'text-red-500'
                }`}>
                  {stat.trend.isPositive ? '+' : '-'}{stat.trend.value}%
                </span>
                <span className="text-muted-foreground ml-1">{stat.trend.period}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

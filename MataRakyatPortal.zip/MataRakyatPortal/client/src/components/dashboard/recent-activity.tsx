import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  CheckCircle, 
  AlertTriangle, 
  Upload, 
  User, 
  Clock,
  ExternalLink,
  Activity
} from "lucide-react";
import type { RecentActivity as RecentActivityType } from "@/lib/types";

interface RecentActivityProps {
  activities: RecentActivityType[];
}

export function RecentActivity({ activities }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'mission_update':
        return CheckCircle;
      case 'assignment':
        return User;
      case 'payment':
        return AlertTriangle;
      case 'evidence':
        return Upload;
      default:
        return Activity;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'mission_update':
        return 'text-green-500 bg-green-500/20';
      case 'assignment':
        return 'text-blue-500 bg-blue-500/20';
      case 'payment':
        return 'text-yellow-500 bg-yellow-500/20';
      case 'evidence':
        return 'text-primary bg-primary/20';
      default:
        return 'text-muted-foreground bg-muted/20';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours} hours ago`;
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString();
  };

  // Mock recent activities if none provided
  const mockActivities = [
    {
      id: '1',
      type: 'mission_update',
      title: 'Mission completed successfully',
      description: 'Agent Martinez submitted final report with conclusive evidence',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      relatedId: 'mission-1'
    },
    {
      id: '2',
      type: 'assignment',
      title: 'New urgent mission assigned',
      description: 'High-priority missing person case requires immediate attention',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      relatedId: 'mission-2'
    },
    {
      id: '3',
      type: 'evidence',
      title: 'Evidence uploaded to case',
      description: 'Agent Davis submitted surveillance footage analysis',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      relatedId: 'evidence-1'
    }
  ];

  const displayActivities = activities.length > 0 ? activities : mockActivities;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2 text-primary" />
            Recent Activity
          </CardTitle>
          <Button variant="ghost" size="sm">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-80">
          {displayActivities.length > 0 ? (
            <div className="space-y-1 p-6 pt-0">
              {displayActivities.map((activity) => {
                const Icon = getActivityIcon(activity.type);
                const colorClasses = getActivityColor(activity.type);
                
                return (
                  <div
                    key={activity.id}
                    className="flex items-start space-x-4 p-4 rounded-lg hover:bg-muted/50 transition-colors group"
                  >
                    <div className={`p-2 rounded-lg ${colorClasses}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground mb-1">
                        {activity.title}
                      </p>
                      <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                        {activity.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">
                          {formatTimestamp(activity.timestamp)}
                        </p>
                        {activity.relatedId && (
                          <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center">
              <Activity className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No recent activity</p>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

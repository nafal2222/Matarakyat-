import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Shield, 
  Eye, 
  MessageCircle,
  Clock,
  CheckCircle,
  AlertCircle,
  Search,
  Filter
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Agent {
  id: string;
  codeName: string;
  realName?: string;
  specializations: string[];
  location: string;
  rating: number;
  completedMissions: number;
  successRate: number;
  isActive: boolean;
  lastActive: string;
  contactPhone?: string;
  contactEmail?: string;
  socialMedia?: {
    telegram?: string;
    whatsapp?: string;
    signal?: string;
  };
  availability: 'available' | 'busy' | 'offline';
  responseTime: string;
}

export function AgentDirectory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [specializationFilter, setSpecializationFilter] = useState("");
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);

  // Sample data - akan diganti dengan API call
  const mockAgents: Agent[] = [
    {
      id: "agent-001",
      codeName: "Shadow Eagle",
      realName: user?.role === 'admin' ? "Budi Santoso" : undefined,
      specializations: ["surveillance", "investigation", "missing_person"],
      location: "Jakarta Selatan",
      rating: 4.8,
      completedMissions: 156,
      successRate: 94.2,
      isActive: true,
      lastActive: "5 menit lalu",
      contactPhone: user?.role === 'admin' ? "+6281234567890" : undefined,
      contactEmail: user?.role === 'admin' ? "shadow.eagle@secure.com" : undefined,
      socialMedia: {
        telegram: "@shadow_eagle_secure",
        whatsapp: "+6281234567890",
        signal: "shadoweagle.01"
      },
      availability: 'available',
      responseTime: "< 30 menit"
    },
    {
      id: "agent-002", 
      codeName: "Silent Wolf",
      realName: user?.role === 'admin' ? "Siti Rahayu" : undefined,
      specializations: ["background_check", "security", "investigation"],
      location: "Bandung",
      rating: 4.9,
      completedMissions: 203,
      successRate: 96.8,
      isActive: true,
      lastActive: "2 menit lalu",
      contactPhone: user?.role === 'admin' ? "+6281987654321" : undefined,
      contactEmail: user?.role === 'admin' ? "silent.wolf@secure.com" : undefined,
      socialMedia: {
        telegram: "@silent_wolf_ops",
        whatsapp: "+6281987654321"
      },
      availability: 'available',
      responseTime: "< 15 menit"
    },
    {
      id: "agent-003",
      codeName: "Night Hawk",
      realName: user?.role === 'admin' ? "Agus Pratama" : undefined,
      specializations: ["lost_items", "surveillance", "security"],
      location: "Surabaya",
      rating: 4.7,
      completedMissions: 98,
      successRate: 91.5,
      isActive: false,
      lastActive: "2 jam lalu",
      contactPhone: user?.role === 'admin' ? "+6281122334455" : undefined,
      contactEmail: user?.role === 'admin' ? "night.hawk@secure.com" : undefined,
      socialMedia: {
        telegram: "@night_hawk_intel"
      },
      availability: 'busy',
      responseTime: "1-2 jam"
    },
    {
      id: "agent-004",
      codeName: "Ghost Rider",
      specializations: ["missing_person", "investigation"],
      location: "Medan",
      rating: 4.6,
      completedMissions: 67,
      successRate: 89.3,
      isActive: true,
      lastActive: "1 menit lalu",
      socialMedia: {
        telegram: "@ghost_rider_search"
      },
      availability: 'available',
      responseTime: "< 45 menit"
    }
  ];

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'available': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'offline': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getAvailabilityText = (availability: string) => {
    switch (availability) {
      case 'available': return 'Tersedia';
      case 'busy': return 'Sibuk';
      case 'offline': return 'Offline';
      default: return 'Tidak Diketahui';
    }
  };

  const filteredAgents = mockAgents.filter(agent => {
    const matchesSearch = agent.codeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         agent.specializations.some(spec => spec.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesLocation = !locationFilter || agent.location.includes(locationFilter);
    const matchesSpecialization = !specializationFilter || agent.specializations.includes(specializationFilter);
    
    return matchesSearch && matchesLocation && matchesSpecialization;
  });

  const handleContactAgent = (agent: Agent, method: string) => {
    toast({
      title: "Kontak Agen",
      description: `Menghubungi ${agent.codeName} via ${method}...`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Direktori Agen Aktif</h2>
          <p className="text-gray-400">
            {filteredAgents.filter(a => a.isActive).length} agen tersedia dari {filteredAgents.length} total agen
          </p>
        </div>
        <Badge className="bg-green-600 text-white animate-pulse">
          <Eye className="h-3 w-3 mr-1" />
          Live Status
        </Badge>
      </div>

      {/* Filters */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Cari nama samaran atau spesialisasi..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <Select value={locationFilter} onValueChange={setLocationFilter}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Filter lokasi..." />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="">Semua Lokasi</SelectItem>
                <SelectItem value="Jakarta">Jakarta</SelectItem>
                <SelectItem value="Bandung">Bandung</SelectItem>
                <SelectItem value="Surabaya">Surabaya</SelectItem>
                <SelectItem value="Medan">Medan</SelectItem>
              </SelectContent>
            </Select>

            <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Filter spesialisasi..." />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="">Semua Spesialisasi</SelectItem>
                <SelectItem value="surveillance">Surveillance</SelectItem>
                <SelectItem value="investigation">Investigasi</SelectItem>
                <SelectItem value="missing_person">Orang Hilang</SelectItem>
                <SelectItem value="background_check">Background Check</SelectItem>
                <SelectItem value="security">Keamanan</SelectItem>
                <SelectItem value="lost_items">Barang Hilang</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Agent Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAgents.map((agent) => (
          <Card key={agent.id} className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-colors">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${agent.codeName}`} />
                      <AvatarFallback className="bg-blue-600 text-white">
                        {agent.codeName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-gray-800 ${getAvailabilityColor(agent.availability)}`} />
                  </div>
                  <div>
                    <CardTitle className="text-white text-lg">{agent.codeName}</CardTitle>
                    {user?.role === 'admin' && agent.realName && (
                      <p className="text-xs text-gray-400">({agent.realName})</p>
                    )}
                    <div className="flex items-center space-x-1 mt-1">
                      <MapPin className="h-3 w-3 text-gray-400" />
                      <span className="text-xs text-gray-400">{agent.location}</span>
                    </div>
                  </div>
                </div>
                <Badge className={`${getAvailabilityColor(agent.availability)} text-white text-xs`}>
                  {getAvailabilityText(agent.availability)}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Stats */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="flex items-center justify-center space-x-1">
                    <Star className="h-3 w-3 text-yellow-400" />
                    <span className="text-sm font-semibold text-white">{agent.rating}</span>
                  </div>
                  <p className="text-xs text-gray-400">Rating</p>
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">{agent.completedMissions}</div>
                  <p className="text-xs text-gray-400">Misi</p>
                </div>
                <div>
                  <div className="text-sm font-semibold text-green-400">{agent.successRate}%</div>
                  <p className="text-xs text-gray-400">Sukses</p>
                </div>
              </div>

              {/* Specializations */}
              <div>
                <p className="text-xs text-gray-400 mb-2">Spesialisasi:</p>
                <div className="flex flex-wrap gap-1">
                  {agent.specializations.slice(0, 3).map((spec) => (
                    <Badge key={spec} variant="secondary" className="text-xs">
                      {spec.replace('_', ' ')}
                    </Badge>
                  ))}
                  {agent.specializations.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{agent.specializations.length - 3}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Response Time */}
              <div className="flex items-center space-x-2">
                <Clock className="h-3 w-3 text-gray-400" />
                <span className="text-xs text-gray-400">Respon: {agent.responseTime}</span>
              </div>

              {/* Last Active */}
              <div className="flex items-center space-x-2">
                {agent.isActive ? (
                  <CheckCircle className="h-3 w-3 text-green-400" />
                ) : (
                  <AlertCircle className="h-3 w-3 text-yellow-400" />
                )}
                <span className="text-xs text-gray-400">Terakhir aktif: {agent.lastActive}</span>
              </div>

              {/* Contact Actions */}
              <div className="space-y-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white"
                      onClick={() => setSelectedAgent(agent)}
                    >
                      <MessageCircle className="h-3 w-3 mr-2" />
                      Hubungi Agen
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gray-800 border-gray-700 text-white">
                    <DialogHeader>
                      <DialogTitle>Kontak {agent.codeName}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      {/* Social Media Contacts */}
                      {agent.socialMedia?.telegram && (
                        <Button
                          variant="outline"
                          className="w-full justify-start border-blue-500 text-blue-400 hover:bg-blue-600"
                          onClick={() => handleContactAgent(agent, 'Telegram')}
                        >
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Telegram: {agent.socialMedia.telegram}
                        </Button>
                      )}
                      
                      {agent.socialMedia?.whatsapp && (
                        <Button
                          variant="outline"
                          className="w-full justify-start border-green-500 text-green-400 hover:bg-green-600"
                          onClick={() => handleContactAgent(agent, 'WhatsApp')}
                        >
                          <Phone className="h-4 w-4 mr-2" />
                          WhatsApp: {agent.socialMedia.whatsapp}
                        </Button>
                      )}

                      {agent.socialMedia?.signal && (
                        <Button
                          variant="outline"
                          className="w-full justify-start border-purple-500 text-purple-400 hover:bg-purple-600"
                          onClick={() => handleContactAgent(agent, 'Signal')}
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          Signal: {agent.socialMedia.signal}
                        </Button>
                      )}

                      {/* Admin-only contacts */}
                      {user?.role === 'admin' && (
                        <>
                          {agent.contactPhone && (
                            <Button
                              variant="outline"
                              className="w-full justify-start border-gray-500 text-gray-400 hover:bg-gray-600"
                              onClick={() => handleContactAgent(agent, 'Phone')}
                            >
                              <Phone className="h-4 w-4 mr-2" />
                              Phone: {agent.contactPhone}
                            </Button>
                          )}
                          
                          {agent.contactEmail && (
                            <Button
                              variant="outline"
                              className="w-full justify-start border-gray-500 text-gray-400 hover:bg-gray-600"
                              onClick={() => handleContactAgent(agent, 'Email')}
                            >
                              <Mail className="h-4 w-4 mr-2" />
                              Email: {agent.contactEmail}
                            </Button>
                          )}
                        </>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredAgents.length === 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-8 text-center">
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Tidak Ada Agen Ditemukan</h3>
            <p className="text-gray-400">Coba ubah filter pencarian atau periksa kembali kriteria Anda.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
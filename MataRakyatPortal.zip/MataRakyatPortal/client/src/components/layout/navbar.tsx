import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { 
  Home, 
  Target, 
  Image, 
  BarChart3, 
  User, 
  Shield,
  Bell,
  LogOut,
  Menu,
  X,
  Settings,
  Search,
  Plus,
  Eye,
  MapPin,
  Clock,
  TrendingUp
} from "lucide-react";
import { useState } from "react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const navItems = [
    { 
      path: "/", 
      label: "Dashboard", 
      icon: Home,
      roles: ["admin", "agent", "mission_provider", "mission_executor"],
      description: "Ringkasan aktivitas platform"
    },
    { 
      path: "/missions", 
      label: "Daftar Misi", 
      icon: Target,
      roles: ["admin", "agent", "mission_provider", "mission_executor"],
      badge: "12",
      description: "Kelola dan pantau semua misi"
    },
    { 
      path: "/evidence", 
      label: "Pusat Bukti", 
      icon: Image,
      roles: ["admin", "agent", "mission_executor"],
      badge: "3",
      description: "Upload dan verifikasi bukti"
    },
    { 
      path: "/agents", 
      label: "Direktori Agen", 
      icon: Eye,
      roles: ["admin", "agent", "mission_provider", "mission_executor"],
      description: "Jaringan agen dengan nama samaran"
    },
    { 
      path: "/analytics", 
      label: "Analitik", 
      icon: BarChart3,
      roles: ["admin", "agent"],
      description: "Laporan dan statistik"
    },
    { 
      path: "/admin", 
      label: "Panel Admin", 
      icon: Shield,
      roles: ["admin"],
      badge: "5",
      description: "Kelola platform dan pengguna"
    }
  ];

  const quickStats = [
    { label: "Misi Aktif", value: "24", icon: Target, color: "text-blue-400" },
    { label: "Terselesaikan Hari Ini", value: "8", icon: TrendingUp, color: "text-green-400" },
    { label: "Pending Review", value: "5", icon: Clock, color: "text-yellow-400" },
    { label: "Total Agent", value: "156", icon: Eye, color: "text-purple-400" }
  ];

  const missionCategories = [
    { name: "Orang Hilang", count: 8, urgent: 2 },
    { name: "Barang Hilang", count: 15, urgent: 1 },
    { name: "Surveillance", count: 12, urgent: 3 },
    { name: "Investigation", count: 6, urgent: 0 },
    { name: "Background Check", count: 9, urgent: 1 },
    { name: "Security", count: 4, urgent: 2 }
  ];

  const filteredNavItems = navItems.filter(item => 
    item.roles.includes(user?.role || "")
  );

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/missions?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  const totalUrgentMissions = missionCategories.reduce((sum, cat) => sum + cat.urgent, 0);

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden lg:flex items-center justify-between p-4 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
        <div className="flex items-center space-x-6">
          <Link href="/">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                <Target className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-white">Mata Rakyat</div>
                <div className="text-xs text-gray-400">Platform Intel Rakyat</div>
              </div>
            </div>
          </Link>
          
          <div className="flex items-center space-x-1">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="sm"
                    className={`flex items-center space-x-2 relative ${
                      isActive 
                        ? "bg-blue-600 text-white shadow-lg" 
                        : "text-gray-300 hover:text-white hover:bg-gray-800"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 text-xs bg-red-500 text-white animate-pulse">
                        {item.badge}
                      </Badge>
                    )}
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Advanced Search */}
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Cari misi, lokasi, atau kategori..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-80 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-blue-500"
            />
          </form>

          {/* Quick Stats Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                <BarChart3 className="h-4 w-4 mr-2" />
                Stats
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-80 bg-gray-800 border-gray-700 text-white">
              <div className="p-4">
                <h3 className="font-semibold mb-3 text-white">Statistik Real-time</h3>
                <div className="grid grid-cols-2 gap-3">
                  {quickStats.map((stat, index) => (
                    <div key={index} className="flex items-center space-x-2 p-2 bg-gray-700 rounded-lg">
                      <stat.icon className={`h-4 w-4 ${stat.color}`} />
                      <div>
                        <div className="text-lg font-bold text-white">{stat.value}</div>
                        <div className="text-xs text-gray-400">{stat.label}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mission Categories */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white relative">
                <Target className="h-4 w-4 mr-2" />
                Kategori Misi
                {totalUrgentMissions > 0 && (
                  <Badge className="ml-2 bg-red-500 text-white text-xs">
                    {totalUrgentMissions} urgent
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-72 bg-gray-800 border-gray-700 text-white">
              <div className="p-4">
                <h3 className="font-semibold mb-3 text-white">Kategori Misi</h3>
                <div className="space-y-2">
                  {missionCategories.map((category, index) => (
                    <Link key={index} href={`/missions?category=${encodeURIComponent(category.name.toLowerCase().replace(' ', '_'))}`}>
                      <div className="flex items-center justify-between p-2 hover:bg-gray-700 rounded-lg cursor-pointer">
                        <span className="text-white">{category.name}</span>
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary" className="text-xs">
                            {category.count}
                          </Badge>
                          {category.urgent > 0 && (
                            <Badge className="bg-red-500 text-white text-xs animate-pulse">
                              {category.urgent} urgent
                            </Badge>
                          )}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Quick Actions */}
          {(user?.role === 'mission_provider' || user?.role === 'admin') && (
            <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white shadow-lg">
              <Plus className="h-4 w-4 mr-2" />
              Buat Misi
            </Button>
          )}
          
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white relative">
            <Bell className="h-4 w-4" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 text-xs bg-red-500 text-white animate-pulse">
              8
            </Badge>
          </Button>
          
          {/* Settings */}
          <Link href="/settings">
            <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
              <Settings className="h-4 w-4" />
            </Button>
          </Link>
          
          {/* User Profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="flex items-center space-x-2 text-gray-300 hover:text-white">
                <User className="h-4 w-4" />
                <div className="text-left">
                  <div className="text-sm font-medium">{user?.firstName || "Pengguna"}</div>
                  <div className="text-xs text-gray-400 capitalize">{user?.role?.replace('_', ' ')}</div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-gray-800 border-gray-700 text-white">
              <DropdownMenuItem asChild>
                <Link href="/profile">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profil Saya</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Pengaturan</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-gray-700" />
              <DropdownMenuItem onClick={handleLogout} className="text-red-400 focus:text-red-300">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Keluar</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <nav className="lg:hidden bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
        <div className="flex items-center justify-between p-4">
          <Link href="/">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-500 rounded-lg flex items-center justify-center">
                <Target className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Mata Rakyat</span>
            </div>
          </Link>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-gray-300 relative">
              <Bell className="h-4 w-4" />
              <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs bg-red-500 text-white">
                8
              </Badge>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-300"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="border-t border-gray-800 bg-gray-900">
            <div className="p-4 space-y-4">
              {/* Mobile Search */}
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Cari misi..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full bg-gray-800 border-gray-700 text-white placeholder-gray-400"
                />
              </form>

              {/* Quick Stats - Mobile */}
              <div className="grid grid-cols-2 gap-2">
                {quickStats.slice(0, 4).map((stat, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-gray-800 rounded-lg">
                    <stat.icon className={`h-4 w-4 ${stat.color}`} />
                    <div>
                      <div className="text-sm font-bold text-white">{stat.value}</div>
                      <div className="text-xs text-gray-400">{stat.label}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Action */}
              {(user?.role === 'mission_provider' || user?.role === 'admin') && (
                <Button size="sm" className="w-full bg-green-600 hover:bg-green-700 text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Buat Misi Baru
                </Button>
              )}

              {/* Navigation Items */}
              <div className="space-y-1">
                {filteredNavItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.path;
                  
                  return (
                    <Link key={item.path} href={item.path}>
                      <Button
                        variant={isActive ? "default" : "ghost"}
                        size="sm"
                        className={`w-full justify-between ${
                          isActive 
                            ? "bg-blue-600 text-white" 
                            : "text-gray-300 hover:text-white hover:bg-gray-800"
                        }`}
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon className="h-4 w-4" />
                          <div className="text-left">
                            <div>{item.label}</div>
                            <div className="text-xs text-gray-400">{item.description}</div>
                          </div>
                        </div>
                        {item.badge && (
                          <Badge className="bg-red-500 text-white text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </Button>
                    </Link>
                  );
                })}
              </div>
              
              <hr className="border-gray-700" />
              
              {/* Profile Section */}
              <div className="space-y-2">
                <Link href="/profile">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start space-x-3 text-gray-300 hover:text-white hover:bg-gray-800"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <User className="h-4 w-4" />
                    <div className="flex-1 text-left">
                      <div className="text-sm font-medium">{user?.firstName || "Profil"}</div>
                      <div className="text-xs text-gray-400 capitalize">{user?.role?.replace('_', ' ')}</div>
                    </div>
                  </Button>
                </Link>

                <Link href="/settings">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start space-x-3 text-gray-300 hover:text-white hover:bg-gray-800"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Settings className="h-4 w-4" />
                    <span>Pengaturan</span>
                  </Button>
                </Link>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="w-full justify-start space-x-3 text-gray-300 hover:text-white hover:bg-red-600"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Keluar</span>
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
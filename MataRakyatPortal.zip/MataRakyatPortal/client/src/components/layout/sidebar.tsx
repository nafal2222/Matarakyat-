import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Home, 
  Search, 
  Database, 
  Users, 
  BarChart3, 
  Settings, 
  Plus, 
  Upload,
  TrendingUp
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";

export function Sidebar() {
  const { user } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/missions", label: "Active Missions", icon: Search },
    { path: "/evidence", label: "Evidence Bank", icon: Database },
    { path: "/team", label: "Team Management", icon: Users },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
    { path: "/settings", label: "Settings", icon: Settings },
  ];

  if (!user) return null;

  return (
    <aside className="fixed left-0 top-16 w-64 h-[calc(100vh-4rem)] bg-card border-r border-border overflow-y-auto hidden lg:block">
      <div className="p-6">
        {/* Quick Actions */}
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Quick Actions
          </h3>
          <div className="space-y-2">
            {(user.role === 'mission_provider' || user.role === 'admin') && (
              <Button className="w-full justify-start">
                <Plus className="h-4 w-4 mr-2" />
                New Mission
              </Button>
            )}
            <Button variant="outline" className="w-full justify-start">
              <Upload className="h-4 w-4 mr-2" />
              Upload Evidence
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="space-y-1 mb-8">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Navigation
          </h3>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <div className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  isActive 
                    ? 'bg-accent/20 text-accent' 
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}>
                  <Icon className="h-4 w-4 mr-3" />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Stats Card */}
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <h4 className="text-sm font-medium mb-2">Mission Success Rate</h4>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold text-green-500">
                {user.successRate || '0'}%
              </span>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </div>
            <Progress 
              value={parseFloat(user.successRate || '0')} 
              className="h-2" 
            />
            <div className="mt-3 space-y-1 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Completed:</span>
                <span className="text-foreground">{user.completedMissions || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Rating:</span>
                <span className="text-foreground">{user.rating || '0.0'}/5.0</span>
              </div>
              <div className="flex justify-between">
                <span>Earnings:</span>
                <span className="text-foreground">${user.totalEarnings || '0'}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}

<?php
/**
 * Mata Rakyat Platform - Auto Installer
 * Sistem instalasi otomatis untuk deployment ke hosting
 */

// Konfigurasi
$config = [
    'app_name' => 'Mata Rakyat Platform',
    'version' => '1.0.0',
    'required_php' => '8.0',
    'required_extensions' => ['pdo', 'pdo_pgsql', 'curl', 'json', 'mbstring'],
    'required_dirs' => ['uploads', 'logs', 'cache', 'sessions'],
    'demo_mode' => true
];

// Database config
$db_config = [
    'host' => $_POST['db_host'] ?? 'localhost',
    'port' => $_POST['db_port'] ?? '5432',
    'database' => $_POST['db_name'] ?? 'mata_rakyat',
    'username' => $_POST['db_user'] ?? 'postgres',
    'password' => $_POST['db_pass'] ?? '',
];

// Admin config
$admin_config = [
    'email' => $_POST['admin_email'] ?? 'admin@matarakyat.local',
    'password' => $_POST['admin_password'] ?? 'admin123',
    'name' => $_POST['admin_name'] ?? 'Administrator'
];

// Social media config
$social_config = [
    'telegram_bot_token' => $_POST['telegram_token'] ?? '',
    'whatsapp_api_key' => $_POST['whatsapp_key'] ?? '',
    'platform_telegram' => $_POST['platform_telegram'] ?? '@mata_rakyat_official',
    'platform_whatsapp' => $_POST['platform_whatsapp'] ?? '+62-8XX-XXXX-XXXX',
    'support_email' => $_POST['support_email'] ?? 'support@matarakyat.local'
];

function showInstallForm() {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Instalasi Mata Rakyat Platform</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #1d4ed8 100%);
                min-height: 100vh; 
                display: flex; 
                align-items: center; 
                justify-content: center;
                color: #333;
            }
            .installer { 
                background: white; 
                padding: 2rem; 
                border-radius: 12px; 
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                width: 100%; 
                max-width: 600px; 
                margin: 2rem;
            }
            .header {
                text-align: center;
                margin-bottom: 2rem;
            }
            .logo {
                width: 80px;
                height: 80px;
                background: linear-gradient(135deg, #3b82f6, #06b6d4);
                border-radius: 16px;
                margin: 0 auto 1rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2rem;
                color: white;
            }
            h1 { 
                color: #1e40af; 
                margin-bottom: 0.5rem;
                font-size: 1.8rem;
            }
            .subtitle {
                color: #6b7280;
                font-size: 1rem;
            }
            .form-group { 
                margin-bottom: 1.5rem; 
            }
            .form-row {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
            }
            label { 
                display: block; 
                margin-bottom: 0.5rem; 
                font-weight: 600;
                color: #374151;
            }
            input, select, textarea { 
                width: 100%; 
                padding: 0.75rem; 
                border: 2px solid #e5e7eb; 
                border-radius: 8px; 
                font-size: 1rem;
                transition: border-color 0.2s;
            }
            input:focus, select:focus, textarea:focus { 
                outline: none; 
                border-color: #3b82f6; 
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
            .btn { 
                background: linear-gradient(135deg, #3b82f6, #1d4ed8); 
                color: white; 
                padding: 1rem 2rem; 
                border: none; 
                border-radius: 8px; 
                cursor: pointer; 
                font-size: 1rem;
                font-weight: 600;
                width: 100%;
                transition: transform 0.2s;
            }
            .btn:hover { 
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
            }
            .section {
                background: #f9fafb;
                padding: 1.5rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
            }
            .section h3 {
                color: #1f2937;
                margin-bottom: 1rem;
                display: flex;
                align-items: center;
            }
            .section h3::before {
                content: "🔧";
                margin-right: 0.5rem;
            }
            .requirement {
                display: flex;
                align-items: center;
                padding: 0.5rem 0;
                border-bottom: 1px solid #e5e7eb;
            }
            .requirement:last-child {
                border-bottom: none;
            }
            .check {
                margin-right: 0.5rem;
                font-size: 1.2rem;
            }
            .check.ok { color: #10b981; }
            .check.error { color: #ef4444; }
            .alert {
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1rem;
            }
            .alert.error {
                background: #fef2f2;
                border: 1px solid #fecaca;
                color: #dc2626;
            }
            .alert.success {
                background: #f0fdf4;
                border: 1px solid #bbf7d0;
                color: #16a34a;
            }
        </style>
    </head>
    <body>
        <div class="installer">
            <div class="header">
                <div class="logo">🎯</div>
                <h1>Mata Rakyat Platform</h1>
                <p class="subtitle">Platform Intel Rakyat - Instalasi Otomatis</p>
            </div>

            <?php 
            // Check system requirements
            $requirements_ok = true;
            echo '<div class="section">';
            echo '<h3>Pemeriksaan Sistem</h3>';
            
            // PHP Version
            $php_ok = version_compare(PHP_VERSION, $GLOBALS['config']['required_php'], '>=');
            $requirements_ok = $requirements_ok && $php_ok;
            echo '<div class="requirement">';
            echo '<span class="check ' . ($php_ok ? 'ok">✓' : 'error">✗') . '</span>';
            echo 'PHP ' . $GLOBALS['config']['required_php'] . '+ (Current: ' . PHP_VERSION . ')';
            echo '</div>';

            // Extensions
            foreach ($GLOBALS['config']['required_extensions'] as $ext) {
                $ext_ok = extension_loaded($ext);
                $requirements_ok = $requirements_ok && $ext_ok;
                echo '<div class="requirement">';
                echo '<span class="check ' . ($ext_ok ? 'ok">✓' : 'error">✗') . '</span>';
                echo 'Extension: ' . $ext;
                echo '</div>';
            }

            // Write permissions
            $write_ok = is_writable('.');
            $requirements_ok = $requirements_ok && $write_ok;
            echo '<div class="requirement">';
            echo '<span class="check ' . ($write_ok ? 'ok">✓' : 'error">✗') . '</span>';
            echo 'Write Permission';
            echo '</div>';

            echo '</div>';

            if (!$requirements_ok) {
                echo '<div class="alert error">❌ Sistem requirements tidak terpenuhi. Silakan hubungi hosting provider Anda.</div>';
            }
            ?>

            <form method="POST" action="">
                <input type="hidden" name="install" value="1">
                
                <div class="section">
                    <h3>Konfigurasi Database</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Database Host</label>
                            <input type="text" name="db_host" value="localhost" required>
                        </div>
                        <div class="form-group">
                            <label>Database Port</label>
                            <input type="number" name="db_port" value="5432" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Database Name</label>
                        <input type="text" name="db_name" value="mata_rakyat" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Database Username</label>
                            <input type="text" name="db_user" value="postgres" required>
                        </div>
                        <div class="form-group">
                            <label>Database Password</label>
                            <input type="password" name="db_pass" required>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h3>Administrator Account</h3>
                    <div class="form-group">
                        <label>Admin Email</label>
                        <input type="email" name="admin_email" value="admin@matarakyat.local" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Admin Password</label>
                            <input type="password" name="admin_password" value="admin123" required>
                        </div>
                        <div class="form-group">
                            <label>Admin Name</label>
                            <input type="text" name="admin_name" value="Administrator" required>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h3>Kontak & Sosial Media Platform</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Telegram Official</label>
                            <input type="text" name="platform_telegram" value="@mata_rakyat_official" placeholder="@username">
                        </div>
                        <div class="form-group">
                            <label>WhatsApp Support</label>
                            <input type="text" name="platform_whatsapp" value="+62-8XX-XXXX-XXXX" placeholder="+62-xxx-xxx-xxx">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Telegram Bot Token (Opsional)</label>
                            <input type="text" name="telegram_token" placeholder="Bot token untuk notifikasi">
                        </div>
                        <div class="form-group">
                            <label>WhatsApp API Key (Opsional)</label>
                            <input type="text" name="whatsapp_key" placeholder="API key untuk WhatsApp">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Support Email</label>
                        <input type="email" name="support_email" value="support@matarakyat.local" required>
                    </div>
                </div>

                <?php if ($requirements_ok): ?>
                <button type="submit" class="btn">🚀 Install Mata Rakyat Platform</button>
                <?php else: ?>
                <button type="button" class="btn" disabled>❌ Fix Requirements First</button>
                <?php endif; ?>
            </form>
        </div>
    </body>
    </html>
    <?php
}

function performInstall() {
    global $db_config, $admin_config, $social_config, $config;
    
    try {
        // 1. Test database connection
        $dsn = "pgsql:host={$db_config['host']};port={$db_config['port']};dbname={$db_config['database']}";
        $pdo = new PDO($dsn, $db_config['username'], $db_config['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // 2. Create directories
        foreach ($config['required_dirs'] as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
        
        // 3. Generate .env file
        $env_content = "# Mata Rakyat Platform Configuration\n";
        $env_content .= "# Generated by Auto Installer\n\n";
        $env_content .= "# Database Configuration\n";
        $env_content .= "DATABASE_URL=\"postgresql://{$db_config['username']}:{$db_config['password']}@{$db_config['host']}:{$db_config['port']}/{$db_config['database']}\"\n";
        $env_content .= "PGHOST=\"{$db_config['host']}\"\n";
        $env_content .= "PGPORT=\"{$db_config['port']}\"\n";
        $env_content .= "PGDATABASE=\"{$db_config['database']}\"\n";
        $env_content .= "PGUSER=\"{$db_config['username']}\"\n";
        $env_content .= "PGPASSWORD=\"{$db_config['password']}\"\n\n";
        
        $env_content .= "# Application Configuration\n";
        $env_content .= "NODE_ENV=production\n";
        $env_content .= "DEMO_MODE=true\n";
        $env_content .= "SESSION_SECRET=\"" . bin2hex(random_bytes(32)) . "\"\n\n";
        
        $env_content .= "# Social Media Configuration\n";
        $env_content .= "PLATFORM_TELEGRAM=\"{$social_config['platform_telegram']}\"\n";
        $env_content .= "PLATFORM_WHATSAPP=\"{$social_config['platform_whatsapp']}\"\n";
        $env_content .= "SUPPORT_EMAIL=\"{$social_config['support_email']}\"\n\n";
        
        if (!empty($social_config['telegram_bot_token'])) {
            $env_content .= "TELEGRAM_BOT_TOKEN=\"{$social_config['telegram_bot_token']}\"\n";
        }
        if (!empty($social_config['whatsapp_api_key'])) {
            $env_content .= "WHATSAPP_API_KEY=\"{$social_config['whatsapp_api_key']}\"\n";
        }
        
        file_put_contents('.env', $env_content);
        
        // 4. Create config.json for client
        $client_config = [
            'app_name' => $config['app_name'],
            'version' => $config['version'],
            'demo_mode' => $config['demo_mode'],
            'social_media' => [
                'telegram' => $social_config['platform_telegram'],
                'whatsapp' => $social_config['platform_whatsapp'],
                'support_email' => $social_config['support_email']
            ],
            'installed_at' => date('Y-m-d H:i:s'),
            'admin_email' => $admin_config['email']
        ];
        
        file_put_contents('config.json', json_encode($client_config, JSON_PRETTY_PRINT));
        
        // 5. Run database setup if init.sql exists
        if (file_exists('init.sql')) {
            $sql = file_get_contents('init.sql');
            $pdo->exec($sql);
        }
        
        // 6. Create admin user
        $admin_password_hash = password_hash($admin_config['password'], PASSWORD_DEFAULT);
        $admin_sql = "INSERT INTO users (id, email, first_name, role, created_at, updated_at) 
                      VALUES (:id, :email, :name, 'admin', NOW(), NOW()) 
                      ON CONFLICT (id) DO UPDATE SET 
                      email = EXCLUDED.email, 
                      first_name = EXCLUDED.first_name,
                      updated_at = NOW()";
        
        $stmt = $pdo->prepare($admin_sql);
        $stmt->execute([
            'id' => 'admin-install-' . time(),
            'email' => $admin_config['email'],
            'name' => $admin_config['name']
        ]);
        
        // 7. Create install success file
        $install_info = [
            'installed' => true,
            'version' => $config['version'],
            'install_date' => date('Y-m-d H:i:s'),
            'admin_email' => $admin_config['email'],
            'demo_mode' => $config['demo_mode']
        ];
        file_put_contents('install.lock', json_encode($install_info, JSON_PRETTY_PRINT));
        
        // Success page
        showSuccessPage();
        
    } catch (Exception $e) {
        showErrorPage($e->getMessage());
    }
}

function showSuccessPage() {
    global $admin_config, $social_config;
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Instalasi Berhasil - Mata Rakyat Platform</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                min-height: 100vh; 
                display: flex; 
                align-items: center; 
                justify-content: center;
                color: #333;
            }
            .success-page { 
                background: white; 
                padding: 3rem; 
                border-radius: 16px; 
                box-shadow: 0 25px 50px rgba(0,0,0,0.15);
                width: 100%; 
                max-width: 700px; 
                margin: 2rem;
                text-align: center;
            }
            .success-icon {
                width: 100px;
                height: 100px;
                background: linear-gradient(135deg, #10b981, #059669);
                border-radius: 50%;
                margin: 0 auto 2rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 3rem;
                animation: bounce 2s infinite;
            }
            @keyframes bounce {
                0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
                40% { transform: translateY(-10px); }
                60% { transform: translateY(-5px); }
            }
            h1 { 
                color: #10b981; 
                margin-bottom: 1rem;
                font-size: 2.5rem;
            }
            .subtitle {
                color: #6b7280;
                font-size: 1.2rem;
                margin-bottom: 2rem;
            }
            .info-card {
                background: #f9fafb;
                border: 2px solid #e5e7eb;
                border-radius: 12px;
                padding: 1.5rem;
                margin: 1rem 0;
                text-align: left;
            }
            .info-card h3 {
                color: #1f2937;
                margin-bottom: 1rem;
                display: flex;
                align-items: center;
            }
            .info-item {
                display: flex;
                justify-content: space-between;
                padding: 0.5rem 0;
                border-bottom: 1px solid #e5e7eb;
            }
            .info-item:last-child {
                border-bottom: none;
            }
            .btn {
                background: linear-gradient(135deg, #3b82f6, #1d4ed8);
                color: white;
                padding: 1rem 2rem;
                border: none;
                border-radius: 8px;
                text-decoration: none;
                display: inline-block;
                margin: 0.5rem;
                font-weight: 600;
                transition: transform 0.2s;
            }
            .btn:hover {
                transform: translateY(-2px);
            }
            .btn.secondary {
                background: linear-gradient(135deg, #6b7280, #4b5563);
            }
        </style>
    </head>
    <body>
        <div class="success-page">
            <div class="success-icon">🎉</div>
            <h1>Instalasi Berhasil!</h1>
            <p class="subtitle">Platform Mata Rakyat telah berhasil diinstall dan siap digunakan</p>
            
            <div class="info-card">
                <h3>🔐 Informasi Login Admin</h3>
                <div class="info-item">
                    <span>Email:</span>
                    <strong><?= htmlspecialchars($admin_config['email']) ?></strong>
                </div>
                <div class="info-item">
                    <span>Password:</span>
                    <strong><?= htmlspecialchars($admin_config['password']) ?></strong>
                </div>
            </div>

            <div class="info-card">
                <h3>📱 Kontak Platform</h3>
                <div class="info-item">
                    <span>Telegram:</span>
                    <strong><?= htmlspecialchars($social_config['platform_telegram']) ?></strong>
                </div>
                <div class="info-item">
                    <span>WhatsApp:</span>
                    <strong><?= htmlspecialchars($social_config['platform_whatsapp']) ?></strong>
                </div>
                <div class="info-item">
                    <span>Support Email:</span>
                    <strong><?= htmlspecialchars($social_config['support_email']) ?></strong>
                </div>
            </div>

            <div class="info-card">
                <h3>⚠️ Keamanan Penting</h3>
                <ul style="list-style: none; padding: 0;">
                    <li>✅ File .env telah dibuat dengan konfigurasi database</li>
                    <li>✅ Mode demo aktif untuk testing</li>
                    <li>🔒 Ubah password admin setelah login pertama</li>
                    <li>🗑️ Hapus file install.php setelah instalasi selesai</li>
                </ul>
            </div>

            <div style="margin-top: 2rem;">
                <a href="/" class="btn">🚀 Masuk ke Platform</a>
                <a href="/demo-login" class="btn secondary">🎯 Demo Login</a>
            </div>

            <div style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 0.9rem;">
                <p>🛡️ Untuk keamanan maksimal, hapus file <code>install.php</code> setelah instalasi selesai</p>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function showErrorPage($error) {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error Instalasi - Mata Rakyat Platform</title>
        <style>
            /* Same base styles as success page but with error colors */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
                min-height: 100vh; 
                display: flex; 
                align-items: center; 
                justify-content: center;
                color: #333;
            }
            .error-page { 
                background: white; 
                padding: 3rem; 
                border-radius: 16px; 
                box-shadow: 0 25px 50px rgba(0,0,0,0.15);
                width: 100%; 
                max-width: 600px; 
                margin: 2rem;
                text-align: center;
            }
            .error-icon {
                width: 100px;
                height: 100px;
                background: linear-gradient(135deg, #ef4444, #dc2626);
                border-radius: 50%;
                margin: 0 auto 2rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 3rem;
                color: white;
            }
            h1 { 
                color: #ef4444; 
                margin-bottom: 1rem;
                font-size: 2rem;
            }
            .error-details {
                background: #fef2f2;
                border: 2px solid #fecaca;
                border-radius: 8px;
                padding: 1rem;
                margin: 1rem 0;
                color: #dc2626;
                text-align: left;
            }
            .btn {
                background: linear-gradient(135deg, #3b82f6, #1d4ed8);
                color: white;
                padding: 1rem 2rem;
                border: none;
                border-radius: 8px;
                text-decoration: none;
                display: inline-block;
                margin-top: 1rem;
                font-weight: 600;
            }
        </style>
    </head>
    <body>
        <div class="error-page">
            <div class="error-icon">❌</div>
            <h1>Error Instalasi</h1>
            <p>Terjadi kesalahan saat menginstall Platform Mata Rakyat:</p>
            
            <div class="error-details">
                <strong>Error:</strong> <?= htmlspecialchars($error) ?>
            </div>

            <p>Silakan periksa konfigurasi database dan coba lagi.</p>
            
            <a href="?" class="btn">🔄 Coba Lagi</a>
        </div>
    </body>
    </html>
    <?php
}

// Main installer logic
if (file_exists('install.lock')) {
    $install_info = json_decode(file_get_contents('install.lock'), true);
    echo "<h1>Platform Already Installed</h1>";
    echo "<p>Mata Rakyat Platform telah diinstall pada: " . $install_info['install_date'] . "</p>";
    echo '<a href="/">Masuk ke Platform</a>';
    exit;
}

if (isset($_POST['install'])) {
    performInstall();
} else {
    showInstallForm();
}
?>
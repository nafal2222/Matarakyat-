-- Setup Data Demo Platform Mata Rakyat
-- Script SQL untuk membuat akun admin dan data demo

-- 1. Insert Admin User
INSERT INTO users (
    id, email, "firstName", "lastName", role, "profileImageUrl", 
    bio, phone, location, "isVerified", rating, "completedMissions", 
    "successRate", "totalEarnings", "createdAt", "updatedAt"
) VALUES (
    'admin-demo-001', 
    'admin@matarakyat.demo', 
    'Administrator', 
    'Platform', 
    'admin', 
    null,
    'Administrator Platform Mata Rakyat untuk demo dan testing',
    '+62811234567',
    'Jakarta, Indonesia',
    true,
    5.0,
    0,
    100.0,
    0,
    NOW(),
    NOW()
) ON CONFLICT (id) DO UPDATE SET "updatedAt" = NOW();

-- 2. Insert Sample Users
INSERT INTO users (
    id, email, "firstName", "lastName", role, bio, phone, location, 
    rating, "completedMissions", "isVerified", "createdAt", "updatedAt"
) VALUES 
(
    'agent-demo-001',
    'agent@matarakyat.demo',
    'Budi',
    'Santoso',
    'agent',
    'Agent berpengalaman di Jakarta dengan spesialisasi pencarian orang hilang',
    '+62812345678',
    'Jakarta Selatan',
    4.8,
    15,
    true,
    NOW(),
    NOW()
),
(
    'provider-demo-001',
    'provider@matarakyat.demo',
    'Siti',
    'Rahayu',
    'mission_provider',
    'Membutuhkan bantuan pencarian untuk keluarga',
    '+62813456789',
    'Bandung',
    4.5,
    3,
    true,
    NOW(),
    NOW()
),
(
    'executor-demo-001',
    'executor@matarakyat.demo',
    'Agus',
    'Pratama',
    'mission_executor',
    'Pelaksana misi profesional dengan pengalaman 5+ tahun',
    '+62814567890',
    'Surabaya',
    4.9,
    28,
    true,
    NOW(),
    NOW()
) ON CONFLICT (id) DO UPDATE SET "updatedAt" = NOW();

-- 3. Insert Sample Missions
INSERT INTO missions (
    title, description, category, priority, location, budget, 
    "providerId", requirements, skills, deadline, status, "assignedTo",
    "createdAt", "updatedAt"
) VALUES 
(
    'Pencarian Anak Hilang - Jakarta Selatan',
    'Anak perempuan bernama Sarah, usia 7 tahun, hilang di area Mall Kemang Village pada hari Sabtu sekitar pukul 15.00. Mengenakan baju pink dan celana jeans. Tinggi sekitar 110cm, rambut panjang dikuncir dua. Keluarga sangat khawatir dan membutuhkan bantuan segera.',
    'missing_person',
    'urgent',
    'Jakarta Selatan',
    5000000,
    'provider-demo-001',
    'Pengalaman pencarian orang hilang, akses ke CCTV area mall, koordinasi dengan security',
    '["investigasi", "komunikasi", "analisis_cctv"]',
    NOW() + INTERVAL '7 days',
    'pending',
    null,
    NOW(),
    NOW()
),
(
    'Dokumen Penting Hilang di Taksi Online',
    'Tas berisi dokumen perusahaan penting hilang di taksi online rute Bandung-Jakarta. Tas hitam merk Samsonite, berisi kontrak kerja, surat-surat penting, dan laptop. Sangat urgent untuk operasional perusahaan. Trip pada tanggal 18 Januari 2024 pukul 14.30.',
    'lost_items',
    'high',
    'Jakarta - Bandung',
    2000000,
    'provider-demo-001',
    'Akses ke data driver ojol, koordinasi dengan customer service, tracking GPS',
    '["investigasi", "koordinasi", "teknologi"]',
    NOW() + INTERVAL '3 days',
    'pending',
    null,
    NOW(),
    NOW()
),
(
    'Pencarian Target DPO - Kasus Penipuan',
    'Pencarian tersangka kasus penipuan investasi bodong atas nama Ahmad Wijaya (41 tahun). Target diketahui sering berada di area Surabaya Timur, khususnya sekitar Rungkut dan Tenggilis. Diperlukan konfirmasi lokasi untuk diserahkan ke pihak berwenang. Kasus telah dilaporkan ke Polda Jatim.',
    'investigation',
    'high',
    'Surabaya',
    10000000,
    'admin-demo-001',
    'Pengalaman investigasi, koordinasi dengan kepolisian, kerahasiaan tinggi',
    '["investigasi_lanjut", "surveillance", "koordinasi_hukum"]',
    NOW() + INTERVAL '14 days',
    'pending',
    null,
    NOW(),
    NOW()
),
(
    'Barang Hilang di Stasiun Gambir',
    'Koper berisi pakaian dan oleh-oleh hilang di Stasiun Gambir saat transit kereta. Koper biru navy ukuran sedang dengan tag nama "RAHAYU". Hilang pada tanggal 19 Januari 2024 sekitar pukul 10.00 saat menunggu kereta ke Bandung.',
    'lost_items',
    'standard',
    'Jakarta Pusat',
    500000,
    'provider-demo-001',
    'Akses ke lost & found stasiun, koordinasi dengan petugas keamanan',
    '["komunikasi", "koordinasi"]',
    NOW() + INTERVAL '5 days',
    'assigned',
    'executor-demo-001',
    NOW(),
    NOW()
);

-- 4. Insert Sample Notifications
INSERT INTO notifications (
    "userId", type, title, message, "isRead", "createdAt"
) VALUES 
(
    'admin-demo-001',
    'system',
    'Platform Mata Rakyat Siap Digunakan',
    'Selamat datang di Platform Mata Rakyat! Sistem telah siap dan data demo telah dimuat. Anda dapat mulai mengelola platform dan memverifikasi misi-misi yang masuk.',
    false,
    NOW()
),
(
    'admin-demo-001',
    'mission_update',
    'Misi Baru Perlu Verifikasi',
    '3 misi baru menunggu verifikasi admin. Silakan tinjau dan proses segera melalui dashboard admin.',
    false,
    NOW()
),
(
    'executor-demo-001',
    'assignment',
    'Anda Ditugaskan ke Misi Baru',
    'Anda telah ditugaskan untuk misi pencarian barang hilang di Stasiun Gambir. Silakan mulai investigasi dan berikan update progress secara berkala.',
    false,
    NOW()
),
(
    'agent-demo-001',
    'system',
    'Akun Agent Telah Aktif',
    'Akun agent Anda telah diverifikasi dan siap digunakan. Anda dapat membantu koordinasi dan verifikasi misi di platform.',
    false,
    NOW()
);

-- 5. Insert Sample Mission Updates
INSERT INTO mission_updates (
    "missionId", "updatedBy", status, notes, "createdAt"
) 
SELECT 
    m.id,
    'executor-demo-001',
    'in_progress',
    'Memulai pencarian di area lost & found stasiun. Sudah koordinasi dengan petugas keamanan dan mendapat akses ke ruang penyimpanan barang hilang.',
    NOW()
FROM missions m 
WHERE m.status = 'assigned' 
LIMIT 1;

-- 6. Insert Sample Evidence
INSERT INTO evidence (
    "missionId", "uploadedBy", "fileName", "filePath", "fileType", 
    description, "fileSize", "isVerified", "createdAt"
)
SELECT 
    m.id,
    'executor-demo-001',
    'foto_area_pencarian.jpg',
    '/uploads/evidence/foto_area_pencarian.jpg',
    'image',
    'Foto area lost & found Stasiun Gambir untuk dokumentasi pencarian',
    245760,
    false,
    NOW()
FROM missions m 
WHERE m.status = 'assigned' 
LIMIT 1;

-- 7. Insert Sample Reviews
INSERT INTO reviews (
    "missionId", "reviewerId", "revieweeId", rating, comment, "createdAt"
)
SELECT 
    m.id,
    'provider-demo-001',
    'executor-demo-001',
    5,
    'Pelaksana misi sangat profesional dan responsif. Memberikan update progress secara berkala dan hasil yang memuaskan.',
    NOW()
FROM missions m 
WHERE m.status = 'assigned' 
LIMIT 1;

-- Tampilkan summary data yang telah diinsert
SELECT 'Data Demo Berhasil Dibuat!' as status;
SELECT COUNT(*) as total_users FROM users;
SELECT COUNT(*) as total_missions FROM missions;
SELECT COUNT(*) as total_notifications FROM notifications;
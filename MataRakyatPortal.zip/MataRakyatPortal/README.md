# Platform Mata Rakyat

Platform informasi pencarian orang hilang, barang hilang, dan koordinasi investigasi dengan sistem pembayaran escrow yang aman.

## 🚀 Fitur Utama

### 📋 Manajemen Misi
- **Pencarian Orang Hilang**: Koordinasi pencarian dengan informasi detail
- **Barang Hilang**: Sistem pelaporan dan pencarian barang
- **Target DPO**: Pencarian target Daftar Pencarian Orang dengan protokol khusus
- **Sistem Escrow**: Pembayaran aman yang ditahan sampai misi selesai

### 👥 Multi-Role System
- **Admin**: Verifikasi misi, moderasi konten, manajemen platform
- **Agent**: Koordinasi lapangan, validasi bukti
- **Pemberi Misi**: Melaporkan kasus, menetapkan kompensasi
- **Pelaksana Misi**: Melakukan pencarian, mengumpulkan bukti

### 🔒 Keamanan & Transparansi
- Sistem escrow payment yang aman
- Verifikasi identitas pengguna
- Rating dan review transparan
- Audit trail lengkap
- Protokol keamanan berlapis

### 📱 Responsif & Modern
- Design responsif untuk mobile dan desktop
- Interface bahasa Indonesia penuh
- Real-time notifications
- Progressive Web App (PWA) ready

## 🛠️ Teknologi

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL + Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **Deployment**: Docker + Docker Compose + Nginx

## 📦 Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/mata-rakyat.git
cd mata-rakyat
```

### 2. Konfigurasi Environment
```bash
cp .env.example .env
# Edit file .env dengan konfigurasi yang sesuai
```

### 3. Deploy dengan Docker
```bash
chmod +x deploy.sh
./deploy.sh
```

### 4. Akses Aplikasi
- **HTTP**: http://localhost
- **HTTPS**: https://localhost (jika SSL dikonfigurasi)
- **Direct**: http://localhost:5000

## 🔧 Manual Setup

### Prerequisites
- Node.js 18+
- PostgreSQL 15+
- Docker & Docker Compose (untuk deployment)

### Development Setup
```bash
# Install dependencies
npm install

# Setup database
npm run db:push

# Start development server
npm run dev
```

## 📁 Struktur Project

```
mata-rakyat/
├── client/                 # Frontend React aplikasi
│   ├── src/
│   │   ├── components/     # Komponen UI reusable
│   │   ├── pages/         # Halaman aplikasi
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities dan konfigurasi
├── server/                # Backend Express API
│   ├── db.ts             # Konfigurasi database
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Database operations
│   └── replitAuth.ts     # Authentication setup
├── shared/               # Shared types dan schema
│   └── schema.ts         # Database schema & types
├── docker-compose.yml    # Docker configuration
├── Dockerfile           # Container setup
├── nginx.conf           # Nginx proxy configuration
└── deploy.sh            # Deployment script
```

## 🔐 Konfigurasi Environment

File `.env` diperlukan dengan konfigurasi berikut:

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/matarakyat
POSTGRES_PASSWORD=your_secure_password

# Session
SESSION_SECRET=your-super-secret-session-key

# Authentication (Replit Auth)
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=yourdomain.com,www.yourdomain.com

# Application
NODE_ENV=production
PORT=5000
```

## 🚀 Deployment Options

### Option 1: Docker Compose (Recommended)
```bash
# Automatic deployment
./deploy.sh

# Manual deployment
docker-compose up -d
```

### Option 2: Cloud Hosting
Platform dapat di-deploy ke:
- **DigitalOcean**: App Platform atau Droplets
- **AWS**: ECS, EC2, atau Elastic Beanstalk
- **Google Cloud**: Cloud Run atau Compute Engine
- **Heroku**: Dengan PostgreSQL add-on
- **Railway**: Deployment otomatis dari GitHub

### Option 3: VPS Manual
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Clone dan deploy
git clone your-repo
cd mata-rakyat
./deploy.sh
```

## 🔒 SSL/HTTPS Setup

### Self-Signed Certificate (Development)
```bash
mkdir ssl
openssl req -x509 -newkey rsa:4096 -keyout ssl/key.pem -out ssl/cert.pem -days 365 -nodes
```

### Let's Encrypt (Production)
```bash
# Install certbot
sudo apt install certbot

# Generate certificate
sudo certbot certonly --standalone -d yourdomain.com

# Copy certificates
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem ssl/cert.pem
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem ssl/key.pem
```

## 📊 Database Schema

Platform menggunakan PostgreSQL dengan schema berikut:
- **users**: Data pengguna dan profil
- **missions**: Misi pencarian dan detail
- **mission_bids**: Penawaran untuk misi
- **payments**: Transaksi dan escrow
- **evidence**: Bukti dan dokumentasi
- **notifications**: Sistem notifikasi
- **reviews**: Rating dan ulasan

## 🔧 Commands

```bash
# Development
npm run dev              # Start development server
npm run build           # Build untuk produksi
npm run preview         # Preview build produksi

# Database
npm run db:push         # Apply schema changes
npm run db:studio       # Open database studio
npm run db:migrate      # Run migrations

# Docker
docker-compose up -d    # Start semua services
docker-compose down     # Stop semua services
docker-compose logs -f  # View logs
docker-compose ps       # Check service status
```

## 🛡️ Keamanan

### Data Protection
- Enkripsi data sensitif
- Secure session management
- SQL injection protection
- XSS protection headers

### Access Control
- Role-based permissions
- JWT token validation
- Rate limiting
- Input sanitization

### Monitoring
- Access logs
- Error tracking
- Performance monitoring
- Security alerts

## 📝 API Documentation

### Authentication Endpoints
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Start login flow
- `GET /api/logout` - Logout user

### Mission Endpoints
- `GET /api/missions` - List missions
- `POST /api/missions` - Create mission
- `PUT /api/missions/:id` - Update mission
- `DELETE /api/missions/:id` - Delete mission

### Admin Endpoints
- `GET /api/admin/pending` - Pending verifications
- `POST /api/admin/approve/:id` - Approve mission
- `POST /api/admin/reject/:id` - Reject mission

## 🤝 Contributing

1. Fork repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

Platform Mata Rakyat adalah sistem informasi yang dikembangkan untuk membantu masyarakat. Platform ini:

- **BUKAN** lembaga penegak hukum resmi
- **BUKAN** organisasi kepolisian
- **BUKAN** penyedia layanan hukum
- **HANYA** sistem informasi dan koordinasi

Untuk kasus darurat, segera hubungi:
- **Polisi**: 110
- **Kominfo**: 129
- **Support Platform**: support@matarakyat.id

## 🆘 Support & Help

### Documentation
- [User Guide](docs/user-guide.md)
- [Admin Guide](docs/admin-guide.md)
- [API Reference](docs/api-reference.md)
- [Deployment Guide](docs/deployment.md)

### Contact
- **Email**: support@matarakyat.id
- **Website**: https://matarakyat.id
- **Issues**: GitHub Issues page

### Emergency Contacts
- **Polisi**: 110 (untuk keadaan darurat)
- **Kominfo**: 129 (untuk laporan konten)

---

**© 2024 Platform Mata Rakyat - Sistem Informasi Pencarian**

*Platform ini hanya untuk tujuan informasi dan koordinasi. Bukan layanan hukum atau penegakan hukum.*
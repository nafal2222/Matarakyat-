-- Inisialisasi Database untuk Platform Mata Rakyat
-- File ini akan dijalankan saat container PostgreSQL pertama kali dibuat

-- Buat database jika belum ada
SELECT 'CREATE DATABASE matarakyat'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'matarakyat')\gexec

-- Buat user dan berikan privileges
DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_user WHERE usename = 'matarakyat_user') THEN
      CREATE USER matarakyat_user WITH PASSWORD 'matarakyat_password';
   END IF;
END
$$;

-- Berikan akses penuh ke database
GRANT ALL PRIVILEGES ON DATABASE matarakyat TO matarakyat_user;

-- Connect ke database matarakyat
\c matarakyat;

-- Berikan privileges untuk schema public
GRANT ALL ON SCHEMA public TO matarakyat_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO matarakyat_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO matarakyat_user;

-- Set default privileges untuk objek yang akan dibuat
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO matarakyat_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO matarakyat_user;
#!/bin/bash

# Script Deployment Platform Mata Rakyat
# Pastikan Docker dan Docker Compose sudah terinstall

set -e

echo "🚀 Memulai deployment Platform Mata Rakyat..."

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Fungsi untuk print dengan warna
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Cek apakah Docker terinstall
if ! command -v docker &> /dev/null; then
    print_error "Docker tidak ditemukan. Silakan install Docker terlebih dahulu."
    exit 1
fi

# Cek apakah Docker Compose terinstall
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose tidak ditemukan. Silakan install Docker Compose terlebih dahulu."
    exit 1
fi

print_info "Memeriksa file konfigurasi..."

# Cek apakah file .env ada
if [ ! -f .env ]; then
    print_warning "File .env tidak ditemukan. Membuat dari template..."
    if [ -f .env.example ]; then
        cp .env.example .env
        print_warning "File .env telah dibuat dari template. Silakan edit file .env dengan konfigurasi yang sesuai."
        print_warning "Tekan Enter untuk melanjutkan setelah mengkonfigurasi .env..."
        read
    else
        print_error "Template .env.example tidak ditemukan!"
        exit 1
    fi
fi

# Cek apakah direktori SSL ada (untuk HTTPS)
if [ ! -d "ssl" ]; then
    print_warning "Direktori SSL tidak ditemukan. Membuat direktori SSL..."
    mkdir -p ssl
    print_warning "Silakan letakkan sertifikat SSL (cert.pem dan key.pem) di direktori ssl/"
    print_warning "Atau gunakan script generate-ssl.sh untuk membuat self-signed certificate"
fi

print_info "Menghentikan container yang sedang berjalan (jika ada)..."
docker-compose down 2>/dev/null || true

print_info "Membersihkan image lama..."
docker system prune -f

print_info "Membangun aplikasi..."
docker-compose build --no-cache

print_info "Menjalankan migrasi database..."
docker-compose up -d postgres
sleep 10

# Tunggu PostgreSQL siap
print_info "Menunggu PostgreSQL siap..."
until docker-compose exec postgres pg_isready -U matarakyat_user -d matarakyat; do
    echo "Menunggu PostgreSQL..."
    sleep 2
done

print_success "PostgreSQL siap!"

print_info "Menjalankan migrasi schema database..."
docker-compose run --rm app npm run db:push

print_info "Menjalankan setup data demo..."
docker-compose run --rm app node setup-demo.js

print_info "Memulai semua service..."
docker-compose up -d

print_info "Menunggu aplikasi siap..."
sleep 15

# Health check
print_info "Melakukan health check..."
for i in {1..30}; do
    if curl -f http://localhost:5000/api/health 2>/dev/null; then
        print_success "Aplikasi berhasil berjalan!"
        break
    else
        echo "Mencoba health check ($i/30)..."
        sleep 2
    fi
    
    if [ $i -eq 30 ]; then
        print_error "Health check gagal. Cek log untuk detail error."
        docker-compose logs app
        exit 1
    fi
done

print_success "🎉 Deployment Platform Mata Rakyat berhasil!"
echo ""
print_info "Aplikasi dapat diakses di:"
print_info "• HTTP: http://localhost"
print_info "• HTTPS: https://localhost (jika SSL dikonfigurasi)"
print_info "• Direct App: http://localhost:5000"
echo ""
print_info "Untuk melihat log:"
echo "docker-compose logs -f"
echo ""
print_info "Untuk menghentikan aplikasi:"
echo "docker-compose down"
echo ""
print_info "Untuk melihat status service:"
echo "docker-compose ps"
#!/usr/bin/env node

// Setup Data Demo Platform Mata Rakyat
// Script untuk membuat akun admin dan data demo lengkap

import pkg from 'pg';
const { Pool } = pkg;

const setupDemo = async () => {
  console.log('🚀 Memulai setup data demo Platform Mata Rakyat...');
  
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://matarakyat_user:matarakyat_password@localhost:5432/matarakyat'
  });

  try {
    // Test koneksi database
    await pool.query('SELECT NOW()');
    console.log('✅ Koneksi database berhasil');

    // 1. Buat Admin User Default
    console.log('👤 Membuat akun admin default...');
    
    await pool.query(`
      INSERT INTO users (
        id, email, first_name, last_name, role, profile_image_url, 
        bio, phone, location, is_verified, rating, completed_missions, 
        success_rate, total_earnings, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW(), NOW()
      ) ON CONFLICT (id) DO UPDATE SET
        updated_at = NOW()
    `, [
      'admin-demo-001', 
      'admin@matarakyat.demo', 
      'Administrator', 
      'Platform', 
      'admin', 
      null,
      'Administrator Platform Mata Rakyat untuk demo dan testing',
      '+62811234567',
      'Jakarta, Indonesia',
      true,
      5.0,
      0,
      100.0,
      0
    ]);

    // 2. Buat Sample Users
    console.log('👥 Membuat sample users...');
    
    const sampleUsers = [
      {
        id: 'agent-demo-001',
        email: 'agent@matarakyat.demo',
        firstName: 'Budi',
        lastName: 'Santoso',
        role: 'agent',
        bio: 'Agent berpengalaman di Jakarta dengan spesialisasi pencarian orang hilang',
        phone: '+62812345678',
        location: 'Jakarta Selatan',
        rating: 4.8,
        completedMissions: 15
      },
      {
        id: 'provider-demo-001',
        email: 'provider@matarakyat.demo',
        firstName: 'Siti',
        lastName: 'Rahayu',
        role: 'mission_provider',
        bio: 'Membutuhkan bantuan pencarian untuk keluarga',
        phone: '+62813456789',
        location: 'Bandung',
        rating: 4.5,
        completedMissions: 3
      },
      {
        id: 'executor-demo-001',
        email: 'executor@matarakyat.demo',
        firstName: 'Agus',
        lastName: 'Pratama',
        role: 'mission_executor',
        bio: 'Pelaksana misi profesional dengan pengalaman 5+ tahun',
        phone: '+62814567890',
        location: 'Surabaya',
        rating: 4.9,
        completedMissions: 28
      }
    ];

    for (const user of sampleUsers) {
      await pool.query(`
        INSERT INTO users (
          id, email, first_name, last_name, role, bio, phone, location, 
          rating, completed_missions, is_verified, created_at, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true, NOW(), NOW()
        ) ON CONFLICT (id) DO UPDATE SET updated_at = NOW()
      `, [
        user.id, user.email, user.firstName, user.lastName, user.role,
        user.bio, user.phone, user.location, user.rating, user.completedMissions
      ]);
    }

    // 3. Buat Sample Missions
    console.log('📋 Membuat sample missions...');
    
    const sampleMissions = [
      {
        title: 'Pencarian Anak Hilang - Jakarta Selatan',
        description: 'Anak perempuan bernama Sarah, usia 7 tahun, hilang di area Mall Kemang Village pada hari Sabtu sekitar pukul 15.00. Mengenakan baju pink dan celana jeans. Tinggi sekitar 110cm, rambut panjang dikuncir dua. Keluarga sangat khawatir dan membutuhkan bantuan segera.',
        category: 'missing_person',
        priority: 'urgent',
        location: 'Jakarta Selatan',
        budget: 5000000,
        providerId: 'provider-demo-001',
        requirements: 'Pengalaman pencarian orang hilang, akses ke CCTV area mall, koordinasi dengan security',
        skills: '["investigasi", "komunikasi", "analisis_cctv"]',
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        status: 'pending'
      },
      {
        title: 'Dokumen Penting Hilang di Taksi Online',
        description: 'Tas berisi dokumen perusahaan penting hilang di taksi online rute Bandung-Jakarta. Tas hitam merk Samsonite, berisi kontrak kerja, surat-surat penting, dan laptop. Sangat urgent untuk operasional perusahaan.',
        category: 'lost_items',
        priority: 'high',
        location: 'Jakarta - Bandung',
        budget: 2000000,
        providerId: 'provider-demo-001',
        requirements: 'Akses ke data driver ojol, koordinasi dengan customer service, tracking GPS',
        skills: '["investigasi", "koordinasi", "teknologi"]',
        deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        status: 'pending'
      },
      {
        title: 'Pencarian Target DPO - Kasus Penipuan',
        description: 'Pencarian tersangka kasus penipuan investasi bodong atas nama Ahmad Wijaya. Target diketahui sering berada di area Surabaya Timur. Diperlukan konfirmasi lokasi untuk diserahkan ke pihak berwenang.',
        category: 'investigation',
        priority: 'high',
        location: 'Surabaya',
        budget: 10000000,
        providerId: 'admin-demo-001',
        requirements: 'Pengalaman investigasi, koordinasi dengan kepolisian, kerahasiaan tinggi',
        skills: '["investigasi_lanjut", "surveillance", "koordinasi_hukum"]',
        deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        status: 'pending'
      },
      {
        title: 'Barang Hilang di Stasiun Gambir',
        description: 'Koper berisi pakaian dan oleh-oleh hilang di Stasiun Gambir saat transit kereta. Koper biru navy ukuran sedang dengan tag nama. Hilang sekitar 2 hari yang lalu.',
        category: 'lost_items',
        priority: 'standard',
        location: 'Jakarta Pusat',
        budget: 500000,
        providerId: 'provider-demo-001',
        requirements: 'Akses ke lost & found stasiun, koordinasi dengan petugas keamanan',
        skills: '["komunikasi", "koordinasi"]',
        deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        status: 'assigned',
        assignedTo: 'executor-demo-001'
      }
    ];

    for (const mission of sampleMissions) {
      await pool.query(`
        INSERT INTO missions (
          title, description, category, priority, location, budget, 
          "providerId", requirements, skills, deadline, status, "assignedTo",
          "createdAt", "updatedAt"
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), NOW()
        ) ON CONFLICT DO NOTHING
      `, [
        mission.title, mission.description, mission.category, mission.priority,
        mission.location, mission.budget, mission.providerId, mission.requirements,
        mission.skills, mission.deadline, mission.status, mission.assignedTo || null
      ]);
    }

    // 4. Buat Sample Notifications
    console.log('🔔 Membuat sample notifications...');
    
    const notifications = [
      {
        userId: 'admin-demo-001',
        type: 'system',
        title: 'Platform Mata Rakyat Siap Digunakan',
        message: 'Selamat datang di Platform Mata Rakyat! Sistem telah siap dan data demo telah dimuat.',
        isRead: false
      },
      {
        userId: 'admin-demo-001',
        type: 'mission_update',
        title: 'Misi Baru Perlu Verifikasi',
        message: '3 misi baru menunggu verifikasi admin. Silakan tinjau dan proses segera.',
        isRead: false
      },
      {
        userId: 'executor-demo-001',
        type: 'assignment',
        title: 'Anda Ditugaskan ke Misi Baru',
        message: 'Anda telah ditugaskan untuk misi pencarian barang hilang di Stasiun Gambir.',
        isRead: false
      }
    ];

    for (const notif of notifications) {
      await pool.query(`
        INSERT INTO notifications (
          "userId", type, title, message, "isRead", "createdAt"
        ) VALUES ($1, $2, $3, $4, $5, NOW())
        ON CONFLICT DO NOTHING
      `, [notif.userId, notif.type, notif.title, notif.message, notif.isRead]);
    }

    console.log('✅ Setup data demo berhasil!');
    console.log('');
    console.log('🎯 Akun Demo yang Tersedia:');
    console.log('');
    console.log('👨‍💼 ADMIN:');
    console.log('   ID: admin-demo-001');
    console.log('   Email: admin@matarakyat.demo'); 
    console.log('   Role: Administrator Platform');
    console.log('   Akses: Verifikasi misi, manajemen user, moderasi konten');
    console.log('');
    console.log('👮‍♂️ AGENT:');
    console.log('   ID: agent-demo-001');
    console.log('   Email: agent@matarakyat.demo');
    console.log('   Role: Agent Lapangan');
    console.log('   Akses: Koordinasi lapangan, validasi bukti');
    console.log('');
    console.log('🙋‍♀️ PEMBERI MISI:');
    console.log('   ID: provider-demo-001');
    console.log('   Email: provider@matarakyat.demo');
    console.log('   Role: Mission Provider');
    console.log('   Akses: Buat misi, monitor progress, kelola pembayaran');
    console.log('');
    console.log('🕵️‍♂️ PELAKSANA MISI:');
    console.log('   ID: executor-demo-001');
    console.log('   Email: executor@matarakyat.demo');
    console.log('   Role: Mission Executor');
    console.log('   Akses: Ambil misi, upload bukti, terima pembayaran');
    console.log('');
    console.log('📊 Data Demo yang Tersedia:');
    console.log('   • 4 Sample missions dengan berbagai kategori dan status');
    console.log('   • Notifikasi untuk testing sistem alert');
    console.log('   • Users dengan rating dan riwayat realistis');
    console.log('   • Data statistik untuk dashboard analytics');
    console.log('');
    console.log('🚀 Platform siap untuk demo dan testing!');
    
    // Query final statistics
    const userCount = await pool.query('SELECT COUNT(*) as count FROM users');
    const missionCount = await pool.query('SELECT COUNT(*) as count FROM missions');
    const notifCount = await pool.query('SELECT COUNT(*) as count FROM notifications');
    
    console.log('');
    console.log('📈 Summary:');
    console.log(`   Users: ${userCount.rows[0].count}`);
    console.log(`   Missions: ${missionCount.rows[0].count}`);
    console.log(`   Notifications: ${notifCount.rows[0].count}`);

  } catch (error) {
    console.error('❌ Error setup demo:', error.message);
    throw error;
  } finally {
    await pool.end();
  }
};

// Jalankan setup
setupDemo().catch((error) => {
  console.error('Setup demo gagal:', error.message);
  process.exit(1);
});

export { setupDemo };
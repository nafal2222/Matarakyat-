import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  uuid,
  pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enums
export const userRoleEnum = pgEnum("user_role", ["admin", "agent", "mission_provider", "mission_executor"]);
export const missionStatusEnum = pgEnum("mission_status", ["pending", "assigned", "in_progress", "completed", "verified", "cancelled", "disputed"]);
export const missionCategoryEnum = pgEnum("mission_category", ["missing_person", "lost_items", "surveillance", "investigation", "background_check", "security"]);
export const missionPriorityEnum = pgEnum("mission_priority", ["low", "standard", "high", "urgent"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "escrowed", "released", "refunded", "disputed"]);
export const evidenceTypeEnum = pgEnum("evidence_type", ["image", "video", "document", "audio", "other"]);
export const notificationTypeEnum = pgEnum("notification_type", ["mission_update", "payment", "assignment", "deadline", "system"]);
export const bidStatusEnum = pgEnum("bid_status", ["pending", "accepted", "rejected", "withdrawn"]);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("mission_executor"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0.00"),
  completedMissions: integer("completed_missions").default(0),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).default("0.00"),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default("0.00"),
  isActive: boolean("is_active").default(true),
  specializations: text("specializations").array(),
  location: varchar("location"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Missions table
export const missions = pgTable("missions", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: missionCategoryEnum("category").notNull(),
  priority: missionPriorityEnum("priority").notNull().default("standard"),
  status: missionStatusEnum("status").notNull().default("pending"),
  location: varchar("location").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }).notNull(),
  deadline: timestamp("deadline").notNull(),
  providerId: varchar("provider_id").notNull(),
  assignedTo: varchar("assigned_to"),
  requirements: text("requirements"),
  skills: text("skills").array(),
  isUrgent: boolean("is_urgent").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  verifiedAt: timestamp("verified_at"),
});

// Mission assignments and bids
export const missionBids = pgTable("mission_bids", {
  id: uuid("id").primaryKey().defaultRandom(),
  missionId: uuid("mission_id").notNull(),
  executorId: varchar("executor_id").notNull(),
  bidAmount: decimal("bid_amount", { precision: 10, scale: 2 }).notNull(),
  proposal: text("proposal").notNull(),
  estimatedCompletionTime: integer("estimated_completion_time"), // in hours
  status: pgEnum("bid_status", ["pending", "accepted", "rejected"])("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payments and escrow
export const payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  missionId: uuid("mission_id").notNull(),
  providerId: varchar("provider_id").notNull(),
  executorId: varchar("executor_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).notNull(),
  status: paymentStatusEnum("status").notNull().default("pending"),
  escrowedAt: timestamp("escrowed_at"),
  releasedAt: timestamp("released_at"),
  refundedAt: timestamp("refunded_at"),
  transactionId: varchar("transaction_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Evidence and files
export const evidence = pgTable("evidence", {
  id: uuid("id").primaryKey().defaultRandom(),
  missionId: uuid("mission_id").notNull(),
  uploadedBy: varchar("uploaded_by").notNull(),
  fileName: varchar("file_name").notNull(),
  fileSize: integer("file_size"),
  fileType: evidenceTypeEnum("file_type").notNull(),
  filePath: varchar("file_path").notNull(),
  description: text("description"),
  isVerified: boolean("is_verified").default(false),
  verifiedBy: varchar("verified_by"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Communications and updates
export const missionUpdates = pgTable("mission_updates", {
  id: uuid("id").primaryKey().defaultRandom(),
  missionId: uuid("mission_id").notNull(),
  userId: varchar("user_id").notNull(),
  updateType: varchar("update_type").notNull(), // status_change, progress_report, message
  content: text("content").notNull(),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").notNull(),
  type: notificationTypeEnum("type").notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  relatedId: varchar("related_id"), // mission_id, payment_id, etc.
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Reviews and ratings
export const reviews = pgTable("reviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  missionId: uuid("mission_id").notNull(),
  reviewerId: varchar("reviewer_id").notNull(),
  revieweeId: varchar("reviewee_id").notNull(),
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  providedMissions: many(missions, { relationName: "provider" }),
  assignedMissions: many(missions, { relationName: "assignee" }),
  bids: many(missionBids),
  payments: many(payments),
  evidence: many(evidence),
  updates: many(missionUpdates),
  notifications: many(notifications),
  reviewsGiven: many(reviews, { relationName: "reviewer" }),
  reviewsReceived: many(reviews, { relationName: "reviewee" }),
}));

export const missionsRelations = relations(missions, ({ one, many }) => ({
  provider: one(users, {
    fields: [missions.providerId],
    references: [users.id],
    relationName: "provider",
  }),
  assignee: one(users, {
    fields: [missions.assignedTo],
    references: [users.id],
    relationName: "assignee",
  }),
  bids: many(missionBids),
  payments: many(payments),
  evidence: many(evidence),
  updates: many(missionUpdates),
  reviews: many(reviews),
}));

export const missionBidsRelations = relations(missionBids, ({ one }) => ({
  mission: one(missions, {
    fields: [missionBids.missionId],
    references: [missions.id],
  }),
  executor: one(users, {
    fields: [missionBids.executorId],
    references: [users.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  mission: one(missions, {
    fields: [payments.missionId],
    references: [missions.id],
  }),
  provider: one(users, {
    fields: [payments.providerId],
    references: [users.id],
  }),
  executor: one(users, {
    fields: [payments.executorId],
    references: [users.id],
  }),
}));

export const evidenceRelations = relations(evidence, ({ one }) => ({
  mission: one(missions, {
    fields: [evidence.missionId],
    references: [missions.id],
  }),
  uploader: one(users, {
    fields: [evidence.uploadedBy],
    references: [users.id],
  }),
}));

export const missionUpdatesRelations = relations(missionUpdates, ({ one }) => ({
  mission: one(missions, {
    fields: [missionUpdates.missionId],
    references: [missions.id],
  }),
  user: one(users, {
    fields: [missionUpdates.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  mission: one(missions, {
    fields: [reviews.missionId],
    references: [missions.id],
  }),
  reviewer: one(users, {
    fields: [reviews.reviewerId],
    references: [users.id],
    relationName: "reviewer",
  }),
  reviewee: one(users, {
    fields: [reviews.revieweeId],
    references: [users.id],
    relationName: "reviewee",
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMissionSchema = createInsertSchema(missions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
  verifiedAt: true,
});

export const insertMissionBidSchema = createInsertSchema(missionBids).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  escrowedAt: true,
  releasedAt: true,
  refundedAt: true,
});

export const insertEvidenceSchema = createInsertSchema(evidence).omit({
  id: true,
  createdAt: true,
  verifiedAt: true,
});

export const insertMissionUpdateSchema = createInsertSchema(missionUpdates).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMission = z.infer<typeof insertMissionSchema>;
export type Mission = typeof missions.$inferSelect;
export type InsertMissionBid = z.infer<typeof insertMissionBidSchema>;
export type MissionBid = typeof missionBids.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertEvidence = z.infer<typeof insertEvidenceSchema>;
export type Evidence = typeof evidence.$inferSelect;
export type InsertMissionUpdate = z.infer<typeof insertMissionUpdateSchema>;
export type MissionUpdate = typeof missionUpdates.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
